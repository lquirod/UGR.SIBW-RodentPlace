// Archivo JavaScript con lass funciones que que se realizan en
// la página web
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
// Función que pliega y despliega la sección de comentarios en las página producto
function toggleComentarios() {
    var section = document.getElementById("seccionComentarios");
    var texto = document.getElementById("botonToggleComentarios");

    if (section.classList.contains('hidden')) {
        section.classList.remove('hidden');
        setTimeout(function () {
        section.classList.remove('visuallyHidden');
        }, 5);
        section.innerHTML.addComment = hola;

    } else {
        section.classList.add('visuallyHidden');    
        section.addEventListener('transitionend', function(e) {
        section.classList.add('hidden');
        }, {
        capture: false,
        once: true,
        passive: false
        });
    }

}
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
// Funciones que gestionan el formulario de la sección de comentarios en la página de productos
//Notificación al usuario si algo falla en el formulario
function notificar(faltanCampos){
    alert('Para poder enviar su comentario necesita:'+ faltanCampos + ' por favor.' );
}
//* * * * * * * * * * * * * * * * * * * */
// Función que filtra algunas palabras y las transforma en ****
function filtroPalabras() {
    let str = document.getElementById("msg").value; 
  let res = str.replace(/tont[ao]|imb[eé][cs]il|mal ?pari|gilipoll|est[uú]pid|jode/gi, "****");
  document.getElementById("msg").value = res;
}
//* * * * * * * * * * * * * * * * * * * */
// Validadación de email sencillo por expresiones regulares
const regularMailExpresion = '/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/';
function validarEmail(mail) {
    // Si es válido
    if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail))
        return (true)
    // Si no es inválido
    return (false)
}
//* * * * * * * * * * * * * * * * * * * */
// Añadir comentario a la sección con el formulario
function addComment() {
    // Se declaran las variables y se toman las respuestas del formulario
    let nombreAutor = document.getElementById('name').value,
        email = document.getElementById('mail').value,
        textComentario = document.getElementById('msg').value,
        d = new Date(),
        fecha = (d.getHours()<10?'0':'')+d.getHours()+':'
              + (d.getMinutes()<10?'0':'')+d.getMinutes()
              +' a '+ d.getDate()+'/'+(d.getMonth()+1)+'/'+d.getFullYear(),
        correcto = true;
        faltanCampos = '';

    // Comprobación de campos del formulario
    // Nombre no vacío
    if(nombreAutor.trim()===''){
        document.getElementById('name').style.borderColor = "red";
        faltanCampos = ' introducir su nombre,';
        correcto = false;
    }else{
        document.getElementById('name').style.borderColor = "#1d3785";
    }

    // Email no vacío
    if(email.trim()===''){
        document.getElementById('mail').style.borderColor = "red";
        faltanCampos = faltanCampos +' introducir un correo electrónico,';
        correcto = false;
    }else{
        // Email correcto
        if(validarEmail(email)){
            document.getElementById('mail').style.borderColor = "#1d3785";
        }else{
            document.getElementById('mail').style.borderColor = "red";
            faltanCampos = faltanCampos +' introducir un correo electrónico válido,';
            correcto = false;
        }
    }
    
    // Texto no vacío
    if(textComentario.trim()===''){
        document.getElementById('msg').style.borderColor = "red";
        faltanCampos = faltanCampos +' introducir un mensaje,';
        correcto = false;
    }else{
        document.getElementById('msg').style.borderColor = "#1d3785";
    }

    // Si todo está correcto y no ha habido ningún error, procederemos a añadir el comentario
    if(correcto){
        // Se crean los contenedores necesarios
        const unComentario = document.createElement('div');
        const autor = document.createElement('span');
        const comentario = document.createElement('p');
        const mostrarFecha = document.createElement('span');

        // Se les pone la clase a los contenedores correspondientes
        unComentario.className = 'unComentario';
        comentario.className = 'cuerpoComentario';
        
        // Se crea el comentario nuevo a añadir
        autor.innerHTML = '<strong>' + nombreAutor + '</strong> ha comentado:';
        comentario.innerHTML = textComentario;
        mostrarFecha.innerHTML = '<em> Escrito a las ' + fecha + '</em>';
        
        // Se añaden los campos al div del comentario
        unComentario.append(autor);
        unComentario.append(comentario);
        unComentario.append(mostrarFecha);

        // Se resetean los campos del formulario
        document.getElementById('name').value = '';
        document.getElementById('mail').value = '';
        document.getElementById('msg').value = '';

        // Se añade el comentario en la sección de comentarios
        publicar = document.getElementById('publicacionComentarios');

        // En primerr lugar, delante del anterior primer comentario
        var segundo_p = publicar.getElementsByTagName('div')[0];
        publicar.insertBefore(unComentario,segundo_p);
        // publicar.appendChild(unComentario);
    }
    else{
        notificar(faltanCampos);
    }
}



