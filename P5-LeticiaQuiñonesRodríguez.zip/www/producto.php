<?php
    session_start();
    require_once "/usr/local/lib/php/vendor/autoload.php";
    require_once "BD/baseDatosProducto.php";
    require_once 'BD/bdUsuarios.php';
  
    $loader = new \Twig\Loader\FilesystemLoader('templates');
    
    $twig = new \Twig\Environment($loader);
    $twig->addExtension(new \Twig\Extension\StringLoaderExtension());

    if (isset($_SESSION['correo'])) {
        $user = getUser($_SESSION['correo']);
    }

    if (isset($_GET['producto']) && filter_var($_GET['producto'], FILTER_VALIDATE_INT) ) {
        $idProducto = filter_var($_GET['producto'], FILTER_VALIDATE_INT);
    } else {
        $idProducto = -1;
    }

    if( existeIDProducto($idProducto) && (isPublicado($idProducto) || $user['GestorSitio']) ){
        $producto = getProducto($idProducto);
        $portada = getPortada($producto['ID']);
        $imagenes = getGaleria($producto['ID']);
        $etiquetas=getEtiquetas($producto['ID']);
        $seccionComentarios = getComentarios($producto['ID']);
        foreach($seccionComentarios as &$unComentario) {
            $commentUser = getBasicUser($unComentario['Correo']);
            $unComentario['Autor'] = $commentUser['nombre'];
            $unComentario['perfil']= $commentUser['imagenPerfil'];
        }
    }else{
        header("Location: index.php");
        exit();
    }


    echo $twig->render('producto.html', ['Producto' => $producto, 'Galeria' => $imagenes, 'Portada' => $portada, 'Etiquetas' => $etiquetas, 'Comentarios' => $seccionComentarios, 'user' => $user]);
?>
