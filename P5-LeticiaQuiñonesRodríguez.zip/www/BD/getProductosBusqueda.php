<?php
    require_once "baseDatosProducto.php";
		
	header('Content-Type: application/json');
	$publicado = false;
    if (isset($_SESSION['correo']) ) {
        $user = getUser($_SESSION['correo']);
		if(($user['GestorSitio']))
			$publicado = true;
    }

    // if (isset($_GET['etiquetas']) ) 
	// 	$etiquetas = $_GET['etiquetas'];
	// else
	// 	$etiquetas = [];

	$busca = $_GET['busca'];

	$idProductos = buscaProducto("busca", [], $publicado);
	// $idProductos = buscaProducto($busca, $etiquetas, $publicado);

	$todosProductos = getProducto($idProductos);
	foreach($todosProductos as &$unProducto) {
		$unProducto['Portada'] = getPortada($unProducto['ID']);
		$unProducto['Galeria'] = getGaleria($unProducto['ID']);
		$unProducto['Etiquetas'] = getEtiquetas($unProducto['ID']);
	}

		echo(json_encode($todosProductos));
?>


