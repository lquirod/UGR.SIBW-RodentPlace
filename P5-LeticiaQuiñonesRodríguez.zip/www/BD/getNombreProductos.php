<?php
    session_start();
    require_once "baseDatosProducto.php";
    require_once "bdUsuarios.php";

	$publicado = false;
    if (isset($_SESSION['correo'])) {
		$user = getUser($_SESSION['correo']);
		if( $user['GestorSitio'] )
			$publicado=true;
	}

    $idProductos = getIDsProductos($publicado);
	$nombreProducto = array();
    foreach ( $idProductos as $unID ) {
        $unProducto = getBasicProducto($unID);
		$nombreProducto [] = $unProducto['Nombre'];
    }

	echo json_encode($nombreProducto);
?>


