<?php
	function conectarBD() {
		return new mysqli("mysql", "Dodyy", "notAdmin", "SIBW");
	}
	function adminBD() {
		return new mysqli("mysql", "Coddy", "yepAdmin", "SIBW");
	}

	// *******************************************************************************************/
	// Productos Información
	//Si existe un ID de producto dado devuekve el valor del ID, si no 0
	function existeIDProducto($idProducto) {
		if(is_numeric($idProducto)){
			$mysqli = conectarBD();
			if ($mysqli->connect_errno) {
				echo ("Fallo al conectar: " . $mysqli->connect_error);
			}
			$res = $mysqli->query("SELECT ID FROM Productos WHERE ID=" . $idProducto);
			if ($res->num_rows == 1) {
				$row = $res->fetch_assoc();
				$producto = $row['ID'];
				return $producto;
			}
		}
		return 0;
	  }

	  function isPublicado($idProducto) {
		if(is_numeric($idProducto)){
			$mysqli = conectarBD();
			if ($mysqli->connect_errno) {
				echo ("Fallo al conectar: " . $mysqli->connect_error);
			}
			$res = $mysqli->query("SELECT Publicado FROM Productos WHERE ID=".$idProducto);
			if ($res->num_rows == 1) {
				$row = $res->fetch_assoc();
				$producto = $row['Publicado'];
				return $producto;
			}
		}
		return false;
	  }

	// Devuelve un array con todos los IDs de los productos
	function getIDsProductos($publicado = false) {
		$mysqli = conectarBD();
		if ($mysqli->connect_errno) {
			echo ("Fallo al conectar: " . $mysqli->connect_error);
		}
		if($publicado){
			$res = $mysqli->query("SELECT ID FROM Productos");
		}else{
			$res = $mysqli->query("SELECT ID FROM Productos WHERE Publicado");
		}
		$producto = array();
		if ($res->num_rows > 0)
		while ($row = mysqli_fetch_assoc($res)) {
			$producto[] = $row['ID'];
		}
		return $producto;
	}

	// Devuelve la información de un producto dado un ID.
	// Si recibe un array de IDs devuelve la información de todos los productos en un array
	function getProducto($idProducto) {
		if(is_numeric($idProducto)){
			if(existeIDProducto($idProducto)){
				$mysqli = conectarBD();
				if ($mysqli->connect_errno) {
					echo ("Fallo al conectar: " . $mysqli->connect_error);
				}
				$res = $mysqli->query("SELECT ID, Nombre, Precio, Descripcion, FichaTecnica, Publicado
				FROM Productos WHERE ID=" . $idProducto);
				$producto = array('ID'          => '0',
								'Nombre'      => 'Producto no encontrado',
								'Precio'      => '-',
								'Descripcion' => '<p>Oops, parece que el producto que desea acceder no está. Compruebe que ha sido buscado correctamente o eche un vistazo a otros productos.</p>',
								'FichaTecnica'=> '<p>Errores: El producto deseado no ha sido identificado en nuestra base de datos.<br>Soluciones: Compruebe que la dirección haya sido escrita correctamente o busque otro producto.</p>',
								'Publicado'   => true,
								);
				if ($res->num_rows > 0) {
					$row = $res->fetch_assoc();
					$producto = array('ID'        => $row['ID'],
									'Nombre'      => $row['Nombre'],
									'Precio'      => $row['Precio'],
									'Descripcion' => $row['Descripcion'],
									'FichaTecnica'=> $row['FichaTecnica'],
									'Publicado'   => $row['Publicado'],
									);
				}
			}
		}else{
			$producto=[];
			$mysqli = conectarBD();
			if ($mysqli->connect_errno) {
				echo ("Fallo al conectar: " . $mysqli->connect_error);
			}
			foreach($idProducto as $unIdProducto)
				if( existeIDProducto($unIdProducto))
				{
					$res = $mysqli->query("SELECT ID, Nombre, Precio, Descripcion, FichaTecnica, Publicado
					FROM Productos WHERE ID=" . $unIdProducto);
					if ($res->num_rows > 0){
						$row = $res->fetch_assoc();
						$producto[] = array('ID'      => $row['ID'],
										'Nombre'      => $row['Nombre'],
										'Precio'      => $row['Precio'],
										'Descripcion' => $row['Descripcion'],
										'FichaTecnica'=> $row['FichaTecnica'],
										'Publicado'   => $row['Publicado'],
									);
					}
				}

		}
		return $producto;
	}

	// Toma sólo la información básica de un producto: Nombre dado un ID
	function getBasicProducto($idProducto) {
		if(is_numeric($idProducto)){
			$mysqli = conectarBD();
			if ($mysqli->connect_errno) {
				echo ("Fallo al conectar: " . $mysqli->connect_error);
			}
			$res = $mysqli->query("SELECT ID, Nombre, Publicado FROM Productos WHERE ID=" . $idProducto);
			if ($res->num_rows > 0) {
				$row = $res->fetch_assoc();
				$nombreIdProducto = array('ID'     => $row['ID'],
										'Nombre' => $row['Nombre'],
										'Portada' => getPortada($row['ID']),
										'Publicado' => $row['Publicado']);
			}else{
				$nombreIdProducto = array('ID'     => '0',
										'Nombre' => '-',
										'Portada' => getPortada(0),
										'Publicado' => false);
			}
		}
		return $nombreIdProducto;
	}

	// Busca productos por nombre o contenido y etiquetas y devuelve su ID
	function buscaProducto($buscarString, $etiquetas, $publicado) {
		$mysqli = conectarBD();
		if ($mysqli->connect_errno) {
			echo ("Fallo al conectar: " . $mysqli->connect_error);
		}

		// Busca etiquetas
		if( 0 < sizeof($etiquetas) ){
			$buscaUnaEtiqueta = [];
			foreach ($etiquetas as $eti){
				if(existeEtiqueta($eti)){
					$eti_secure = mysqli_real_escape_string($mysqli, $eti);
					$buscaUnaEtiqueta []= " E.Etiqueta =\"".$eti_secure."\" ";
				}
			}
			$buscaEti_secure = " LEFT JOIN Etiquetas E ON P.ID=E.idProducto WHERE (".$buscaUnaEtiqueta.join(" OR ").") AND ";
		}else
			$buscaEti_secure = " WHERE ";
		
		// Busca si está publicado o no
		if($publicado)
			$publicado_secure = " Publicado AND ";
		else
			$publicado_secure = "";

		// Busca en todos los campos
		$busca_secure = mysqli_real_escape_string($mysqli, $buscarString);
		$buscaString_secure = " ( LOWER(P.Nombre)     LIKE CONCAT('%',LOWER(\"".$busca_secure."\"),'%')
							OR LOWER(P.Precio)       LIKE CONCAT('%',LOWER(\"".$busca_secure."\"),'%')
							OR LOWER(P.Descripcion)  LIKE CONCAT('%',LOWER(\"".$busca_secure."\"),'%')
							OR LOWER(P.FichaTecnica) LIKE CONCAT('%',LOWER(\"".$busca_secure."\"),'%') ) ";

		$sql = "SELECT P.ID FROM Productos P ".$buscaEti_secure.$publicado_secure.$buscaString_secure;
		$res = $mysqli->query($sql);
		if ($res->num_rows > 0) {
			$producto = [];
			while ($row = mysqli_fetch_assoc($res)) {
				$producto[] = $row['ID'];
				// $producto []= array( $row['Nombre'], $row['ID']);
				// $producto = array('ID'        => $row['ID'],
				// 				'Nombre'      => $row['Nombre'],
				// 				'Precio'      => $row['Precio'],
				// 				'Descripcion' => $row['Descripcion'],
				// 				'FichaTecnica'=> $row['FichaTecnica'],
				// 				'Publicado'   => $row['Publicado'],
				// );
			}
		}else{
				$producto = 0;
			// $nombreIdProducto = array('ID'     => '0',
			// 						'Nombre' => '-',
			// 						'Portada' => getPortada(0),
			// 						'Publicado' => false);
		}

		return $producto;
	}

	// *******************************************************************************************/
	// Gestión Productos
	// Añadir la información de un producto a la base de datos
	function addProducto($nombre, $precio, $descripcion, $ficha, $publicado = false) {
		if(is_numeric($precio)){
			$mysqli = adminBD();
			if ($mysqli->connect_errno) {
				echo ("Fallo al conectar: " . $mysqli->connect_error);
			}
			$nombre_secure = mysqli_real_escape_string($mysqli, $nombre);
			$precio_secure = mysqli_real_escape_string($mysqli, $precio);
			$descripcion_secure = mysqli_real_escape_string($mysqli, $descripcion);
			$ficha_secure = mysqli_real_escape_string($mysqli, $ficha);
			if($publicado)
				$publicado_secure = mysqli_real_escape_string($mysqli, "1");
			else
				$publicado_secure = mysqli_real_escape_string($mysqli, "0");

			$sql = "INSERT INTO Productos (Nombre, Precio, Descripcion, FichaTecnica, Publicado)
			VALUES( '$nombre_secure', '$precio_secure', '$descripcion_secure', '$ficha_secure', '$publicado_secure')";
			$mysqli->query($sql);
			return $mysqli->affected_rows;
		}
		return 0;
	}

	// Edita la información de un producto
	function editProducto($idProducto, $nombre, $precio, $descripcion, $ficha, $publicado) {
		if(is_numeric($idProducto) && existeIDProducto($idProducto) && is_numeric($precio)){
			$mysqli = adminBD();
			if ($mysqli->connect_errno) {
				echo ("Fallo al conectar: " . $mysqli->connect_error);
			}
			$nombre_secure = mysqli_real_escape_string($mysqli, $nombre);
			$descripcion_secure = mysqli_real_escape_string($mysqli, $descripcion);
			$ficha_secure = mysqli_real_escape_string($mysqli, $ficha);
			if($publicado){
				$publicado_secure = mysqli_real_escape_string($mysqli, "1");
			}else{
				$publicado_secure = mysqli_real_escape_string($mysqli, "0");
			}

			$sql = "UPDATE Productos SET Nombre = '$nombre_secure', Precio = '$precio', Descripcion = '$descripcion_secure',
			FichaTecnica = '$ficha_secure', Publicado = ".$publicado_secure." WHERE ID=\"".$idProducto."\"";
			// echo $sql;
			
			$mysqli->query($sql);
			return $mysqli->affected_rows;
		}
		return 0;
	}

	// Elimina un producto de la base de datos
	function eliminarProducto($idProducto) {
		if( is_numeric($idProducto) && existeIDProducto($idProducto)){
			$mysqli = adminBD();
			if ($mysqli->connect_errno) {
					echo ("Fallo al conectar: " . $mysqli->connect_error);
			}
			$sql = "DELETE FROM Productos WHERE ID=\"".$idProducto."\"";
			$mysqli->query($sql);
			return $mysqli->affected_rows;
		}
	}

	// *******************************************************************************************/
	// Etiquetas
	// Devuelve 'true' si existe la etiqueta dada, 'false' en caso contrario
	// Las etiquetas existentes están asociadas a un producto 0
	function existeEtiqueta($etiqueta) {
		$mysqli = conectarBD();
		if ($mysqli->connect_errno) {
			echo ("Fallo al conectar: " . $mysqli->connect_error);
		}
		$etiqueta_secure = mysqli_real_escape_string($mysqli, $etiqueta);

		$sql = "SELECT Etiqueta FROM Etiquetas WHERE idProducto='0' AND Etiqueta=\"".$etiqueta_secure."\"";
		$mysqli->query($sql);
		if ($mysqli->affected_rows == 1) {
			return true;
		}
		return false;
	}

	// Toma las etiquetas de un producto.
	// Por defecto, o si se pasa el valor 0 u otro int con ID no válido se devuelven todas las etiquetas disponibles
	function getEtiquetas($idProducto = 0) {
		if(is_numeric($idProducto)){
			$mysqli = conectarBD();
			if ($mysqli->connect_errno) {
				echo ("Fallo al conectar: " . $mysqli->connect_error);
			}
			if(!existeIDProducto($idProducto)){
				$idProducto = 0;
			}
			$res = $mysqli->query("SELECT Etiqueta FROM Etiquetas WHERE idProducto=" . $idProducto);
			if ($res->num_rows > 0)
			while ($row = mysqli_fetch_assoc($res)) {
				$etiquetas[] = $row['Etiqueta'];
			}
		}
		return $etiquetas;
	}

	// Añade una etiqueta a un producto
	function addEtiqueta($etiqueta, $idProducto = 0) {
		if(is_numeric($idProducto) && (existeIDProducto($idProducto) || $idProducto == 0)){
			$mysqli = adminBD();
			if ($mysqli->connect_errno) {
				echo ("Fallo al conectar: " . $mysqli->connect_error);
			}
			$etiqueta_secure = mysqli_real_escape_string($mysqli, $etiqueta);
			$sql = "INSERT INTO Etiquetas (idProducto, Etiqueta) VALUES( '$idProducto', '$etiqueta_secure')";
			$mysqli->query($sql);
			return $mysqli->affected_rows;
		}
		return 0;
	}

	// Edita las etiquetas de un producto. Para ello se eliminan todas y se añaden las deseadas
	function editEtiquetas($idProducto, $etiquetas) {
		if(is_numeric($idProducto) && existeIDProducto($idProducto)){
			$mysqli = adminBD();
			if ($mysqli->connect_errno) {
					echo ("Fallo al conectar: " . $mysqli->connect_error);
			}
			$sql = "DELETE FROM Etiquetas WHERE idProducto=\"".$idProducto."\"";
			$mysqli->query($sql);
			foreach ($etiquetas as $eti){
				if(existeEtiqueta($eti)){
					addEtiqueta($eti, $idProducto);
				}
			}
		}
	}

	// *******************************************************************************************/
	// Galería
	// Toma el nombre de la imagen de la portada de un producto dado su ID
	function getPortada($idProducto) {
		if(is_numeric($idProducto)){
			$mysqli = conectarBD();
			if ($mysqli->connect_errno) {
				echo ("Fallo al conectar: " . $mysqli->connect_error);
			}
			if(existeIDProducto($idProducto)){
				$res = $mysqli->query("SELECT Imagen FROM Galeria WHERE idProducto=" . $idProducto . " AND Portada");
				if ($res->num_rows > 0) {
					$row = $res->fetch_assoc();
					$Portada = $row['Imagen'];
				}
			}else{		
				$def = $mysqli->query("SELECT Imagen FROM Galeria WHERE idProducto='0' AND Portada");
				$row = $def->fetch_assoc();
				$Portada = $row['Imagen'];
			}
		}
		return $Portada;
	}

	// Edita la imagen de portada de un producto
	function editPortada($idProducto, $img) {
		if(is_numeric($idProducto)){
			$mysqli = adminBD();
			if ($mysqli->connect_errno) {
				echo ("Fallo al conectar: " . $mysqli->connect_error);
			}
			if(existeIDProducto($idProducto)){
				$mysqli->query("DELETE FROM Galeria WHERE idProducto=\"".$idProducto."\" AND Portada");
				$img_secure = mysqli_real_escape_string($mysqli, $img);
				$sql = "INSERT INTO Galeria (idProducto, Imagen, Portada) VALUES('$idProducto', '$img_secure', TRUE)";
				$mysqli->query($sql);
				return $mysqli->affected_rows;
			}
		}
	}

	// Devuelve la galería de fotos de un producto dado su ID
	function getGaleria($idProducto) {
		if(is_numeric($idProducto)){
			$mysqli = conectarBD();
			if ($mysqli->connect_errno) {
				echo ("Fallo al conectar: " . $mysqli->connect_error);
			}
			$res = $mysqli->query("SELECT Imagen FROM Galeria WHERE idProducto=" . $idProducto . " AND ( Portada=0 OR Portada IS NULL) ");
			$Imagenes = array();
			if ($res->num_rows > 0)
			while ($row = mysqli_fetch_assoc($res)) {
				$Imagenes[] = $row['Imagen'];
			}
		}
		return $Imagenes;
	}

	// Añade una imagen a la galería de un producto
	function addGaleria($idProducto, $img) {
		if(existeIDProducto($idProducto)){
			$mysqli = adminBD();
			if ($mysqli->connect_errno) {
				echo ("Fallo al conectar: " . $mysqli->connect_error);
			}
			$img_secure = mysqli_real_escape_string($mysqli, $img);
			$sql = "INSERT INTO Galeria (idProducto, Imagen) VALUES('$idProducto', '$img_secure')";
			$mysqli->query($sql);
			return $mysqli->affected_rows;
		}
	}

	// Elimina una imagen de la galería de un producto
	function eliminarGaleria($idProducto, $img) {
		if(is_numeric($idProducto) && existeIDProducto($idProducto)){
			$mysqli = adminBD();
			if ($mysqli->connect_errno) {
					echo ("Fallo al conectar: " . $mysqli->connect_error);
			}
			$img_secure = mysqli_real_escape_string($mysqli, $img);

			$sql = "DELETE FROM Galeria WHERE idProducto=\"".$idProducto."\" AND Imagen=\"".$img_secure."\"";
			$mysqli->query($sql);
			return $mysqli->affected_rows;
		}
	}

	// *******************************************************************************************/
	// Comentarios
	// Función que da un formato a una fecha
	function formatFecha($mysqlDate) {
		$formattedDate = date("H:i, d/m/Y", strtotime($mysqlDate));
		return $formattedDate;
	}

	// Devuelve true si existe un comentario dado su ID
	function existeIDComentario($idComentario) {
		if(is_numeric($idComentario)){
			$mysqli = conectarBD();
			if ($mysqli->connect_errno) {
				echo ("Fallo al conectar: " . $mysqli->connect_error);
			}
			$res = $mysqli->query("SELECT idComentario FROM Comentarios WHERE idComentario=".$idComentario);
			if ($res->num_rows == 1) {
				$row = $res->fetch_assoc();
				$comentario = $row['idComentario'];
				return $comentario;
			}
		}
		return 0;
	}

	// Devuelve los comentarios de un producto dado su ID
	// Devuelve un sólo comentario si se especifica el ID del comentario
	function getComentarios($idProducto, $format = 1, $idComentario = 0) {
		if(is_numeric($idProducto)&&is_numeric($format)&&is_numeric($idComentario)){
			$mysqli = conectarBD();
			if ($mysqli->connect_errno) {
				echo ("Fallo al conectar: " . $mysqli->connect_error);
			}
			if($idComentario == 0){
				$res = $mysqli->query("SELECT idComentario, idProducto, Correo, Comentario, Fecha FROM Comentarios WHERE idProducto=" . $idProducto . " ORDER BY Fecha DESC ");
				$Comentarios = array();
				if ($res->num_rows > 0)
				while ($row = mysqli_fetch_assoc($res)) {
					if($format){
						$Comentarios[] = array('idComentario'    => $row['idComentario'],
											'idProducto'    => $row['idProducto'],
											'Correo'    => $row['Correo'],
											'Comentario'=> $row['Comentario'],
											'Fecha'     => formatFecha($row['Fecha']));
					}else{
						$Comentarios[] = array('idComentario'    => $row['idComentario'],
											'idProducto'    => $row['idProducto'],
											'Correo'    => $row['Correo'],
											'Comentario'=> $row['Comentario'],
											'Fecha'     => $row['Fecha']);
					}
				}
			}else{
				$res = $mysqli->query("SELECT idComentario, idProducto, Correo, Comentario, Fecha FROM Comentarios
					WHERE idComentario=" . $idComentario);
				$Comentarios = array();
				if ($res->num_rows > 0){
					$row = $res->fetch_assoc();
					if($format){
						$Comentarios = array('idComentario'    => $row['idComentario'],
											'idProducto'    => $row['idProducto'],
											'Correo'    => $row['Correo'],
											'Comentario'=> $row['Comentario'],
											'Fecha'     => formatFecha($row['Fecha']));
					}else{
						$Comentarios = array('idComentario'    => $row['idComentario'],
											'idProducto'    => $row['idProducto'],
											'Correo'    => $row['Correo'],
											'Comentario'=> $row['Comentario'],
											'Fecha'     => $row['Fecha']);
					}
				}
			}

		}
		return $Comentarios;
	}

	// Añade un comentario a un producto
	function addComentario($idProducto, $correo, $texto, $fecha) {
		if(is_numeric($idProducto)){
		$mysqli = adminBD();
		if ($mysqli->connect_errno) {
				echo ("Fallo al conectar: " . $mysqli->connect_error);
			}
			$idProducto_secure = mysqli_real_escape_string($mysqli, $idProducto);
			$correo_secure = mysqli_real_escape_string($mysqli, $correo);
			$texto_secure = mysqli_real_escape_string($mysqli, $texto);
			$fecha_secure = mysqli_real_escape_string($mysqli, $fecha);

			$sql = "INSERT INTO Comentarios (idProducto, Correo, Comentario, Fecha) VALUES ( '$idProducto_secure', '$correo_secure', '$texto_secure', '$fecha_secure')";
			$mysqli->query($sql);
		}
		return $mysqli->affected_rows;
	}

	// Edita el contenido de un comentario
	function editComentario($idComentario, $mensaje) {
		if(is_numeric($idComentario)){
			$mysqli = adminBD();
			if ($mysqli->connect_errno) {
				echo ("Fallo al conectar: " . $mysqli->connect_error);
			}
			if(existeIDComentario($idComentario)){
				$msg_secure = mysqli_real_escape_string($mysqli, $mensaje);
				$sql = "UPDATE Comentarios SET Comentario = '$msg_secure' WHERE idComentario=\"".$idComentario."\"";
				$mysqli->query($sql);
				return $mysqli->affected_rows;
			}
		}
	}

	// Elimina un comentario
	function eliminarComentario($idComentario) {
		if(is_numeric($idComentario)){
			$mysqli = adminBD();
			if ($mysqli->connect_errno) {
					echo ("Fallo al conectar: " . $mysqli->connect_error);
			}
			if(existeIDComentario($idComentario)){
				$sql = "DELETE FROM Comentarios WHERE idComentario=\"".$idComentario."\"";
				$mysqli->query($sql);
				return $mysqli->affected_rows;
			}
		}

	}

?>
