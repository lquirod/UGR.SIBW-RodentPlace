<?php
  session_start();
  require_once "/usr/local/lib/php/vendor/autoload.php";

  $loader = new \Twig\Loader\FilesystemLoader('templates');
  $twig = new \Twig\Environment($loader);
  
  require_once 'BD/bdUsuarios.php';
  $err;
  
  if (isset($_SESSION['correo'])) {
    header("Location: miCuenta.php");
    exit();
  }
  
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $correo = $_POST['correo'];
    $pass = $_POST['contraseña'];
  
    if (checkLogin($correo, $pass)) {
      session_start();
      
      $_SESSION['correo'] = $correo;
      header("Location: miCuenta.php");
      exit();
    }else{
      $err[] = 'Correo no registrado o contraseña incorrecta';
    }
    
  }
  
  echo $twig->render('login.html', ['errores' => $err]);

  // $page_id = mysql_real_escape_sts
  // mysql_query(" UPDATE ratings(vote) VALUES ('$rating') WHERE id = '$page_id' ");
  //<meta http-equiv="refresh" content="3;url=http://www.google.com/" />


  ?>