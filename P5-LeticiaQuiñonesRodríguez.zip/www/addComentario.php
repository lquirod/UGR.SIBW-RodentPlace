<?php
    session_start();
    require_once "/usr/local/lib/php/vendor/autoload.php";
    require_once "BD/baseDatosProducto.php";
    require_once 'BD/bdUsuarios.php';
  
    $loader = new \Twig\Loader\FilesystemLoader('templates');
    
    $twig = new \Twig\Environment($loader);
    $twig->addExtension(new \Twig\Extension\StringLoaderExtension());


    if (isset($_GET['producto']) && filter_var($_GET['producto'], FILTER_VALIDATE_INT) ) {
        $idProducto = filter_var($_GET['producto'], FILTER_VALIDATE_INT);
    } else {
        $idProducto = -1;
    }
  
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['correo']) && $idProducto != -1 ) {
		$correo = $_SESSION['correo'];
		$texto = $_REQUEST['msg'];
		$timezone = date_default_timezone_get();
		date_default_timezone_set($timezone);
		$fecha = date('Y-m-d H:i:s', time());
		$ret = addComentario($idProducto, $correo, $texto, $fecha);
    }

	if($idProducto == -1){
		$location = "Location: index.php";
	}else{
		$location = "Location: producto.php?producto=".$idProducto;
	}

	header($location);
	exit();
?>
