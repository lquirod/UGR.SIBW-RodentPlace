<?php
    session_start();
    require_once "/usr/local/lib/php/vendor/autoload.php";
    require_once "BD/baseDatosProducto.php";
    require_once 'BD/bdUsuarios.php';
  
    $loader = new \Twig\Loader\FilesystemLoader('templates');
    
    $twig = new \Twig\Environment($loader);
    $twig->addExtension(new \Twig\Extension\StringLoaderExtension());

    // Si está iniciado sesión se toma la información del usuario
    // Si no, se redirige al login
    if (isset($_SESSION['correo'])) {
        $user = getUser($_SESSION['correo']);
    }else{
        header("Location: login.php");
        exit();
    }

    // Si tiene permisos de gestor se edita la información, si no se redirige a la página principal
    if($user['GestorPermisos']){
        if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user'])) {
            $editUser = $_POST['user'][0];
            if(!existeUser($editUser)){
                $errores[] = "No se ha podido encontrar al usuario";
            }
            if(strcmp($editUser, $user['correo'])){
                $Moderador = isset($_POST['Moderador'][0]);
                $GestorSitio = isset($_POST['GestorSitio'][0]);
                $GestorPermisos = isset($_POST['GestorPermisos'][0]);
                editPermisosUser($editUser, $Moderador, $GestorSitio, $GestorPermisos);
            }else{
                $errores[] = "No puedes modificar tus propios permisos";
            }
        }
    }else{
        header("Location: index.php");
        exit();
    }
    $todosUsuarios = getAllUsers();

    if (!empty($errores)) {
        $message = "";
        foreach ($errores as $e){
            $message = $message.$e;
        }
        echo "<script type='text/javascript'>alert('$message');</script>";
    }
    echo $twig->render('editUsers.html', ['todosUsuarios' => $todosUsuarios, 'user' => $user]);
?>
