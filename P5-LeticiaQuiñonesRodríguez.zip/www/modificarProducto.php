<?php
    session_start();
    require_once "/usr/local/lib/php/vendor/autoload.php";
    require_once "BD/baseDatosProducto.php";
    require_once 'BD/bdUsuarios.php';
  
    $loader = new \Twig\Loader\FilesystemLoader('templates');
    
    $twig = new \Twig\Environment($loader);
    $twig->addExtension(new \Twig\Extension\StringLoaderExtension());

    if (isset($_SESSION['correo'])) {
        $user = getUser($_SESSION['correo']);
    }else{
        header("Location: login.php");
        exit();
    }

    if(($user['GestorSitio'])){
      if (isset($_GET['producto']) && filter_var($_GET['producto'], FILTER_VALIDATE_INT)){
        $idProducto = filter_var($_GET['producto'], FILTER_VALIDATE_INT);
      }else{
        $idProducto = 0;
      }
      
      if(isset($_GET['delete']) && filter_var($_GET['delete'], FILTER_VALIDATE_INT) == 1) {
        eliminarProducto($idProducto);
      }elseif($_SERVER['REQUEST_METHOD'] === 'POST'){
        $nombre = $_REQUEST['Nombre'];
        $precio = $_REQUEST['Precio'];
        $descripcion = $_REQUEST['Descripcion'];
        $ficha = $_REQUEST['FichaTecnica'];
        if(isset($_POST['Publicado']))
          $publicado = true;
        else
          $publicado = false;
          
        editProducto($idProducto, $nombre, $precio, $descripcion, $ficha, $publicado);

        $etiquetas = $_POST['checkEtiqueta'];
        editEtiquetas($idProducto, $etiquetas);
// echo print_r($etiquetas);
      }

    }else{
      header("Location: index.php");
      exit();
    }

    header("Location: gestProducto.php?producto=".$idProducto);
    exit();
?>
