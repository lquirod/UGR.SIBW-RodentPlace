<?php
    session_start();
    require_once "/usr/local/lib/php/vendor/autoload.php";
    require_once 'BD/baseDatosProducto.php';
    require_once 'BD/bdUsuarios.php';

    $loader = new \Twig\Loader\FilesystemLoader('templates');
    $twig = new \Twig\Environment($loader);
    
    if (isset($_SESSION['correo'])) {
      	$user = getUser($_SESSION['correo']);
    }

    if (isset($_GET['page']) && (0 < filter_var($_GET['page'], FILTER_VALIDATE_INT))){
      	$page = filter_var($_GET['page'], FILTER_VALIDATE_INT);
    }else{
		$page = 0;
    }

    $showProd = 12;
    $publicado = false;
    if( $user['GestorSitio'] )
		$publicado=true;

    $producto = array();
    $idProductos = getIDsProductos($publicado);
    $cont = $showProd*$page;

    if($cont >= count($idProductos)){
		$cont = 0;
		$page = 0;
    }

    for (; $cont < $showProd+($showProd*$page) && $cont < count($idProductos); $cont = $cont + 1 ) {
        $producto [] = getBasicProducto($idProductos[$cont]);
    }

    if($cont+1 < count($idProductos)){
      $SigPage = true;
    }else{
      $SigPage = false;
    }

    $todasEtiquetas = getEtiquetas();

    echo $twig->render('portada.html', ['Producto' => $producto, 'user' => $user, 'Page' => $page, 'SigPage' => $SigPage, 'todasEtiquetas' => $todasEtiquetas] );
?>

