<?php
    session_start();
    require_once "/usr/local/lib/php/vendor/autoload.php";
    require_once "BD/baseDatosProducto.php";
    require_once 'BD/bdUsuarios.php';
  
    $loader = new \Twig\Loader\FilesystemLoader('templates');
    
    $twig = new \Twig\Environment($loader);
    $twig->addExtension(new \Twig\Extension\StringLoaderExtension());

    // Si está iniciado sesión se toma la información del usuario
    // Si no, se redirige al login
    if (isset($_SESSION['correo'])) {
        $user = getUser($_SESSION['correo']);
    }else{
        header("Location: login.php");
        exit();
    }

    // Si se va a editar un comentario concreto
    if (isset($_GET['comentario']) && filter_var($_GET['comentario'], FILTER_VALIDATE_INT) ) {
        $idComentario = existeIDComentario(filter_var($_GET['comentario'], FILTER_VALIDATE_INT));
        if($idComentario){
            $editComentario = getComentarios(0, 1, $idComentario);
            $editComentario['nombreProducto'] =  getMostrarProducto($editComentario['idProducto'])['Nombre'];
        }
    }

    // Si no es dueño del comentario
    if(strcmp($user['correo'], $editComentario['Correo']) && !($user['Moderador'])){
        header("Location: index.php");
        exit();
    }

    // Si es moderador toma la lista de comentarios
    if($user['Moderador']){
        if (isset($_GET['producto']) && filter_var($_GET['producto'], FILTER_VALIDATE_INT)) {
            $idProducto = filter_var($_GET['producto'], FILTER_VALIDATE_INT);
        } else {
            $idProducto = "TODO";
        }

        if(existeIDProducto($idProducto)){
            $producto[] = $idProducto;
        }else{
            $producto = getIDsProductos(true);
        }

        $seccionComentarios = array();
        foreach($producto as $unProducto) {
            $seccionComentarios[] = array(
                'Producto' => getBasicProducto($unProducto),
                'Comentarios' => getComentarios($unProducto, 0)
            );
        }
    }

    echo $twig->render('editComentario.html', ['todosComentarios' => $seccionComentarios, 'user' => $user, 'editComentario' => $editComentario]);
?>
