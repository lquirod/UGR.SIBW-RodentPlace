<?php
    session_start();
    require_once "/usr/local/lib/php/vendor/autoload.php";
    require_once "BD/baseDatosProducto.php";
    require_once 'BD/bdUsuarios.php';
  
    $loader = new \Twig\Loader\FilesystemLoader('templates');
    
    $twig = new \Twig\Environment($loader);
    $twig->addExtension(new \Twig\Extension\StringLoaderExtension());

    // Si está iniciado sesión se toma la información del usuario
    // Si no, se redirige al login
    if (isset($_SESSION['correo'])) {
        $user = getUser($_SESSION['correo']);
    }else{
        header("Location: login.php");
        exit();
    }

    if (isset($_GET['producto']) && filter_var($_GET['producto'], FILTER_VALIDATE_INT)){
        $idProducto = filter_var($_GET['producto'], FILTER_VALIDATE_INT);
    }else{
        $idProducto = 0;
    }

    // Si tiene permisos de gestor se edita la información, si no se redirige a la página principal
    if($user['GestorSitio'] && existeIDProducto($idProducto)){
        // Si se indica la eliminación de un producto
        if(isset($_GET['delete']) && filter_var($_GET['delete'], FILTER_VALIDATE_INT) == 1) {
            $delImg = $_GET['img'];
            eliminarGaleria($idProducto, $delImg);
        }elseif($_SERVER['REQUEST_METHOD'] === 'POST' && existeIDProducto($idProducto)){
            // Si se indica el cambio de imagen de una portada
            if(isset($_GET['portada']) && filter_var($_GET['portada'], FILTER_VALIDATE_INT) == 1) {
                if(isset($_FILES['imgPortada'])){
                    $imgPortada = $_FILES['imgPortada']['name'];
                    $file_size = $_FILES['imgPortada']['size'];
                    $file_tmp = $_FILES['imgPortada']['tmp_name'];
                    $file_type = $_FILES['imgPortada']['type'];
                    $file_ext = strtolower(end(explode('.',$_FILES['imgPortada']['name'])));
                    $extensions= array("jpeg","jpg","png");
                    
                    if($imgPortada!=""){
                        if(in_array($file_ext,$extensions) === false){
                            $erroresPortada[] = 'Extensión de la portada no permitida (JPEG o PNG)';
                        }elseif ($file_size > 2097152){
                            $erroresPortada[] = 'Tamaño del fichero para la portada demasiado grande';
                        }
                    }else{
                        $erroresPortada[] = 'Ninguna imagen seleccionada para la portada';
                    }
                    if (empty($erroresPortada)==true) {                  
                        $ret = editPortada($idProducto, $imgPortada);
                        if($ret){
                            move_uploaded_file($file_tmp, "images/productos/" . $imgPortada);
                        }else{
                            $erroresPortada[] = 'No se ha podido cambiar la portada, en la base de datos';
                        }
                    }
                }
            }else{
                // Si se va a añadir imágenes a la galería de un producto
                if(isset($_FILES['newImagen'])){
                    $newImagen = $_FILES['newImagen']['name'];
                    $file_size = $_FILES['newImagen']['size'];
                    $file_tmp = $_FILES['newImagen']['tmp_name'];
                    $file_type = $_FILES['newImagen']['type'];
                    $extensions= array("jpeg","jpg","png");
                    $total = count($newImagen);

                    for( $i=0 ; $i < $total ; $i++ ) {
                        $file_ext = strtolower(end(explode('.',$newImagen[$i])));
                        if($newImagen[$i]!=""){
                            if(in_array($file_ext,$extensions) === false){
                                $erroresGaleria[$i][] = "Image $i: Extensión no permitida para añadir a la galería (JPEG o PNG)";
                            }elseif ($file_size[$i] > 2097152){
                                $erroresGaleria[$i][] = "Image $i: Tamaño del fichero para añadir a la galería demasiado grande";
                            }
                        }else{
                            $erroresGaleria[$i][] = "Image $i: No se ha dectectado ninguna imagen";
                        }
                        if (empty($erroresGaleria[$i])==true) {                  
                            $ret = addGaleria($idProducto, $newImagen[$i]);
                            if($ret){
                                move_uploaded_file($file_tmp[$i], "images/productos/" .$newImagen[$i]);
                            }else{
                                $erroresGaleria[$i][] = 'No se ha podido añadir la imagen a la galería a la base de datos';
                            }
                        }
                    }
                }
            }
        }
    }else{
        header("Location: index.php");
        exit();
    }

    // Se toma infomación del producto y sus comentarios
    $producto = getProducto($idProducto);
    $portada = getPortada($producto['ID']);
    if($producto['ID'] != 0 ){
        $imagenes = getGaleria($producto['ID'] );
        $seccionComentarios = getComentarios($producto['ID']);
        foreach($seccionComentarios as &$unComentario) {
            $commentUser = getBasicUser($unComentario['Correo']);
            $unComentario['Autor'] = $commentUser['nombre'];
            $unComentario['perfil']= $commentUser['imagenPerfil'];
        }
    }

    echo $twig->render('producto.html', ['Producto' => $producto, 'Galeria' => $imagenes, 'Portada' => $portada,
    'Comentarios' => $seccionComentarios, 'user' => $user, 'erroresPortada' => $erroresPortada, 'erroresGaleria' => $erroresGaleria]);

?>
