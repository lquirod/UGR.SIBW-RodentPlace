// Archivo JavaScript con lass funciones de búsqueda con AJAX
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
$(document).ready(function() {
    $("#esperaMensaje").hide();
    $("#errorMensaje").hide();
});
function buscarIncidencias( tipo) {
    $("#errorMensaje").hide();
    var palabras = $("#inputBuscador").val();

    if(tipo=='GEST' || tipo =='PROD'){
        // var etiquetasCheck = [];//$("#checkEtiqueta");
        // var etiqResult = $('input[type="checkbox"]:checked');
        // if (etiqResult.length > 0)
        // {
        //     etiqResult.each(function(){
        //         etiquetasCheck.push($(this).val());
        //     });        
        // };

        if(palabras.trim()===''){
            $("#errorMensaje").show();
            $("#errorMensaje").html(" El campo de búsqueda no puede estar vacío");
        }else{
            $.ajax({
                data: {busca: palabras}, //, etiquetas: etiquetasCheck},
                url: 'BD/getProductosBusqueda.php',
                type: 'get',
                beforeSend: function () {
                    $("#esperaMensaje").show();
                },
                success: function(respuesta) {
                    $("#esperaMensaje").hide();
                    if(tipo=='GEST'){
                        resProductGest(respuesta);
                    }else{
                        resProductMost(respuesta);
                    }
                },
                error: function(XMLHttpRequest, textStatus, errorThrown) {
                    $("#esperaMensaje").hide();
                $("#errorMensaje").show();
                $("#errorMensaje").html(" Status: " + textStatus+"<br>Error: " + errorThrown);
                }
            });
        }
    }
}
function resProductMost(respuesta) {    
    if(respuesta.length != 1){
        var res = '';
        for (i = 0 ; i < respuesta.length ; i++) {
            var unaLinea = '';
            unaLinea += '<a href="producto.php?producto='+respuesta[i].ID+'"><div>';
            unaLinea += '<img src="images/productos/'+respuesta[i].Portada+'" class="imagen"/>';
            unaLinea += '</div><div class="productText">'  +respuesta[i].Nombre +'</div></a>';
            
            if(respuesta[i].Publicado == 0)
                unaLinea = '<div class="Oscuro">'+unaLinea+'</div>'
            unaLinea = '<article class="productPhoto object3 objectLine">'+unaLinea+'</article>';

            res += unaLinea;
        }
    }else{
        window.location.href = "producto.php?producto="+respuesta[0].ID;
    }
    
    $("#muestraProductos").html(res);
}

function resProductGest(respuesta) {
    if(respuesta.length != 1){
        var res = '';
        for (i = 0 ; i < respuesta.length ; i++) {
            var unaLinea = '';
            unaLinea += '<td><div class="smallColumn"><a href="gestProducto.php?producto='+respuesta[i].ID+'">'+respuesta[i].ID+'<i class="fa-regular fa-pen-to-square"></i></a></div></td>';
            unaLinea += '<td><div class="lineColumn">'+respuesta[i].Nombre+'</div></td>';
            unaLinea += '<td><div class="">'+respuesta[i].Precio+'</div></td>';
            unaLinea += '<td><div class="largeColumn">'+respuesta[i].Descripcion+'</div></td>';
            unaLinea += '<td><div class="largeColumn">'+respuesta[i].FichaTecnica+'</div></td>';
            unaLinea += '<td><div class="smallColumn"><a href="producto.php?producto='+respuesta[i].ID+'#galeriaImagenesProducto">'+respuesta[i].Galeria.length+'<i class="fa-solid fa-images"></i></a></div>';
            
            if(respuesta[i].Publicado == 0)
            unaLinea = '<tr class="Oscuro">'+unaLinea+'</tr>';
            else
            unaLinea = '<tr>' +unaLinea+ '</tr>';
            
            res += unaLinea;
        }
    }else{
        window.location.href = "gestProducto.php?producto="+respuesta[0].ID;
    }
    
    $("#tablaProductos > tbody").html(res);
}



/* ***************************************************************************************************** */
// Función de predicción de búsqueda
document.addEventListener('readystatechange', event => {
	if (event.target.readyState === "complete") {
        // Preparar el nombre de los productos
        var productosArray = [];
		var xhttp = new XMLHttpRequest();
        xhttp.open("GET", "http://localhost/BD/getNombreProductos.php", true);
        xhttp.send();
		xhttp.onreadystatechange = function(){
            if(xhttp.readyState == 4 && xhttp.status == 200) {
				var getNombresJSON = JSON.parse(xhttp.responseText);
                for(index = 0; index < getNombresJSON.length; index++) {
                    productosArray.push(getNombresJSON[index]);
                }
			}
		};
        autocomplete(document.getElementById("inputBuscador"), productosArray);

	}
});

function autocomplete(inp, arr) {
    /*the autocomplete function takes two arguments,
    the text field element and an array of possible autocompleted values:*/
    var currentFocus;
    /*execute a function when someone writes in the text field:*/
    inp.addEventListener("input", function(e) {
        var a, b, i, val = this.value;
        /*close any already open lists of autocompleted values*/
        closeAllLists();
        if (!val) { return false;}
        currentFocus = -1;
        /*create a DIV element that will contain the items (values):*/
        a = document.createElement("DIV");
        a.setAttribute("id", this.id + "autocomplete-list");
        a.setAttribute("class", "autocomplete-items");
        /*append the DIV element as a child of the autocomplete container:*/
        this.parentNode.appendChild(a);
        /*for each item in the array...*/
        for (i = 0; i < arr.length; i++) {
          /*check if the item starts with the same letters as the text field value:*/
          if (arr[i].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
            /*create a DIV element for each matching element:*/
            b = document.createElement("DIV");
            /*make the matching letters bold:*/
            b.innerHTML = "<strong>" + arr[i].substr(0, val.length) + "</strong>";
            b.innerHTML += arr[i].substr(val.length);
            /*insert a input field that will hold the current array item's value:*/
            b.innerHTML += "<input type='hidden' value='" + arr[i] + "'>";
            /*execute a function when someone clicks on the item value (DIV element):*/
            b.addEventListener("click", function(e) {
                /*insert the value for the autocomplete text field:*/
                inp.value = this.getElementsByTagName("input")[0].value;
                /*close the list of autocompleted values,
                (or any other open lists of autocompleted values:*/
                closeAllLists();
            });
            a.appendChild(b);
          }
        }
    });
    /*execute a function presses a key on the keyboard:*/
    inp.addEventListener("keydown", function(e) {
        var x = document.getElementById(this.id + "autocomplete-list");
        if (x) x = x.getElementsByTagName("div");
        if (e.keyCode == 40) {
          /*If the arrow DOWN key is pressed,
          increase the currentFocus variable:*/
          currentFocus++;
          /*and and make the current item more visible:*/
          addActive(x);
        } else if (e.keyCode == 38) { //up
          /*If the arrow UP key is pressed,
          decrease the currentFocus variable:*/
          currentFocus--;
          /*and and make the current item more visible:*/
          addActive(x);
        } else if (e.keyCode == 13) {
          /*If the ENTER key is pressed, prevent the form from being submitted,*/
          e.preventDefault();
          if (currentFocus > -1) {
            /*and simulate a click on the "active" item:*/
            if (x) x[currentFocus].click();
          }
        }
    });
    function addActive(x) {
      /*a function to classify an item as "active":*/
      if (!x) return false;
      /*start by removing the "active" class on all items:*/
      removeActive(x);
      if (currentFocus >= x.length) currentFocus = 0;
      if (currentFocus < 0) currentFocus = (x.length - 1);
      /*add class "autocomplete-active":*/
      x[currentFocus].classList.add("autocomplete-active");
    }
    function removeActive(x) {
      /*a function to remove the "active" class from all autocomplete items:*/
      for (var i = 0; i < x.length; i++) {
        x[i].classList.remove("autocomplete-active");
      }
    }
    function closeAllLists(elmnt) {
      /*close all autocomplete lists in the document,
      except the one passed as an argument:*/
      var x = document.getElementsByClassName("autocomplete-items");
      for (var i = 0; i < x.length; i++) {
        if (elmnt != x[i] && elmnt != inp) {
          x[i].parentNode.removeChild(x[i]);
        }
      }
    }
    /*execute a function when someone clicks in the document:*/
    document.addEventListener("click", function (e) {
        closeAllLists(e.target);
    });
  }
  