-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: mysql:3306
-- Generation Time: Jun 12, 2022 at 08:27 PM
-- Server version: 8.0.28
-- PHP Version: 8.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `docker`
--

-- --------------------------------------------------------

--
-- Table structure for table `Comentarios`
--

CREATE TABLE `Comentarios` (
  `idProducto` int NOT NULL,
  `idComentario` int NOT NULL,
  `Correo` varchar(50) NOT NULL,
  `Comentario` text NOT NULL,
  `Fecha` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `Comentarios`
--

INSERT INTO `Comentarios` (`idProducto`, `idComentario`, `Correo`, `Comentario`, `Fecha`) VALUES
(1, 1, 'user2@gmail.com', 'Le compramos esta rueda a la cobaya de nuestra hija y queda bastante bonita en la habitación', '2022-03-16 20:35:48'),
(1, 2, 'user@gmail.com', 'El modelo de rueda más grande necesita algo de peso en la base ya que se tambalea y alguna vez por la mañana la hemos visto volcada', '2022-03-24 19:45:12'),
(2, 3, 'user5@gmail.com', 'Mi hijo casi todos los días le pone a nuestros hámsters los tubos de colores de una forma distinta así que es bastante entretenido tanto para las mascotas como para los niños jaja', '2022-01-28 12:47:30'),
(2, 4, 'user4@gmail.com', 'Hay que tener cuidado sobre todo ahora en verano con dejar los tubos al sol porque se calientan al tacto y no creo que sea muy seguro ya que mis degús se meten poco', '2021-08-26 16:22:07'),
(3, 5, 'user3@gmail.com', 'Bonitas, buena calidad, la tela no es demasiado gruesa, se puede usar para primavera', '2021-04-03 21:06:04'),
(3, 6, 'user2@gmail.com', 'Muy contenta con esta compra! El material es suave ido y muy bonito. Lo compré para mi pyrrhura y le encanta dormir dentro y sacar el pico por uno de los agujeros. Me encanta haber acertado ', '2022-02-20 09:48:14'),
(3, 7, 'user@gmail.com', 'La forma y el funcionamiento me gusta mucho, pero el tejido no ya que es de pelito y mi hámster se ha dedicado a roerlo todo. ', '2021-04-18 13:03:37'),
(5, 8, 'user4@gmail.com', 'La verdad es que iba muy bien para mis hamsters, corrían por toda la casa y era fantástico....pero el otro día se rompió y pobre animalito, que susto se llevó!', '2021-05-24 17:20:52'),
(5, 9, 'user5@gmail.com', 'A mi ratoncito le encanta pasearse por toda la casa en la rueda y es super gracioso porque se acerca al perro y lo mueve para todos lados', '2022-04-07 10:41:01'),
(6, 10, 'user@gmail.com', 'Se engancha bien y fácil en la jaula, el agua no gotea', '2021-12-27 14:56:14'),
(6, 11, 'user3@gmail.com', 'Llego rapido y en buen estado se agarra bien a la jaula sin problema', '2022-01-14 18:02:34'),
(7, 12, 'user4@gmail.com', 'Buena opción de compra para los que tengáis un par de cobayas. Muy espaciosa y alta. Eso si, pesa un poco. Muy Recomendable su compra.', '2021-09-18 12:47:06'),
(7, 13, 'user@gmail.com', 'He comprado esta jaula porque quería separar una parejita de conejos. En cuanto a calidad me parece muy buena ya que tengo otra igual desde hace un año que está a la intemperie y de momento está intacta,aunque tengo que decir que vivo en el sur. ', '2021-05-16 10:43:27'),
(8, 14, 'user@gmail.com', 'Muy buen producto que permite ver al animal y debido a la base de vidrio evita todas las proyecciones de astillas o aserrín. el animal tiene espacio y puede trepar sin problema, dejando la comida encima, se mantiene limpio por más tiempo.', '2021-06-03 12:47:11'),
(8, 15, 'user1@gmail.com', 'Puerta un poco pequeña pero producto de gran calidda. Llegado rapidamente y perfectamente embalado. Permite multiples distribuciones interiores. Perfecto para una pareja de ratas', '2021-08-06 16:40:03'),
(8, 16, 'user@gmail.com', 'Tenemos una hamster rusa. Antes vivía en una jaula mucho más pequeña. Estamos contentos con la nueva. Es muy grande para ella, En la parte de abajo pusimos una casita adicional de madera, es donde acostumbra a esconderse. La jaula es fácil de desmontar y limpiar aunque al ser de cristal lógicamente pesa. Estéticamente nos parece más bonita que una de plástico, al ser de cristal y hierro negro.', '2022-03-28 15:57:04'),
(9, 17, 'user3@gmail.com', 'Buena calidad, bonita grande muy buena compra', '2022-05-16 10:15:54'),
(9, 18, 'user2@gmail.com', 'La jaula montada queda muy bonita y tiene un muy buen tamaño. Cubrid bien el \"suelo\" de la jaula con algún material impermeable antes de poner la paja porque si no la madera absorberá el pipí ', '2022-04-07 17:34:10');

-- --------------------------------------------------------

--
-- Table structure for table `Etiquetas`
--

CREATE TABLE `Etiquetas` (
  `idProducto` int NOT NULL,
  `Etiqueta` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `Etiquetas`
--

INSERT INTO `Etiquetas` (`idProducto`, `Etiqueta`) VALUES
(0, 'Accesorio de Jaula'),
(0, 'Accesorio de mascota'),
(0, 'Comida'),
(0, 'Cuidados'),
(0, 'Decoración'),
(0, 'Higiene'),
(0, 'Jaula'),
(0, 'Juguete'),
(0, 'Salud'),
(0, 'Utensilio'),
(1, 'Accesorio de Jaula'),
(1, 'Juguete'),
(1, 'Salud'),
(2, 'Accesorio de Jaula'),
(2, 'Juguete'),
(3, 'Accesorio de Jaula'),
(3, 'Cuidados'),
(3, 'Salud'),
(4, 'Comida'),
(4, 'Salud'),
(5, 'Juguete'),
(5, 'Salud'),
(6, 'Cuidados'),
(6, 'Utensilio'),
(7, 'Jaula'),
(8, 'Jaula'),
(9, 'Jaula');

-- --------------------------------------------------------

--
-- Table structure for table `Galeria`
--

CREATE TABLE `Galeria` (
  `idProducto` int NOT NULL,
  `Imagen` varchar(40) NOT NULL,
  `Portada` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `Galeria`
--

INSERT INTO `Galeria` (`idProducto`, `Imagen`, `Portada`) VALUES
(0, '0producto.jpg', 1),
(1, '1producto_1.jpg', NULL),
(1, '1producto_2.jpg', NULL),
(1, '1producto_3.jpg', NULL),
(1, '1producto.jpg', 1),
(2, '2producto_1.jpg', NULL),
(2, '2producto_2.jpg', NULL),
(2, '2producto_3.jpg', NULL),
(2, '2producto_4.jpg', NULL),
(2, '2producto_5.jpg', NULL),
(2, '2producto.jpg', 1),
(3, '3producto_1.jpg', NULL),
(3, '3producto_2.jpg', NULL),
(3, '3producto_3.jpg', NULL),
(3, '3producto_4.jpg', NULL),
(3, '3producto_5.jpg', NULL),
(3, '3producto_6.jpg', NULL),
(3, '3producto.jpg', 1),
(4, '4producto_1.jpg', NULL),
(4, '4producto.jpg', 1),
(5, '5producto_1.jpg', NULL),
(5, '5producto_2.jpg', NULL),
(5, '5producto_3.jpg', NULL),
(5, '5producto_4.jpg', NULL),
(5, '5producto.jpg', 1),
(6, '6producto_1.jpg', NULL),
(6, '6producto_2.jpg', NULL),
(6, '6producto_3.jpg', NULL),
(6, '6producto.jpg', 1),
(7, '7producto_1.jpg', NULL),
(7, '7producto_2.jpg', NULL),
(7, '7producto_3.jpg', NULL),
(7, '7producto.jpg', 1),
(8, '8producto_1.jpg', NULL),
(8, '8producto_2.jpg', NULL),
(8, '8producto_3.jpg', NULL),
(8, '8producto.jpg', 1),
(9, '9producto_1.jpg', NULL),
(9, '9producto_2.jpg', NULL),
(9, '9producto_3.jpg', NULL),
(9, '9producto_4.jpg', NULL),
(9, '9producto.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `PalabrasBaneadas`
--

CREATE TABLE `PalabrasBaneadas` (
  `Palabras` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `PalabrasBaneadas`
--

INSERT INTO `PalabrasBaneadas` (`Palabras`) VALUES
('coñ[oa]'),
('est[uú]pid'),
('gili'),
('idiot'),
('imb[eé][cs]il'),
('jode'),
('mal ?pari'),
('me ?cago'),
('polla'),
('put[ao]'),
('tont[ao]');

-- --------------------------------------------------------

--
-- Table structure for table `Productos`
--

CREATE TABLE `Productos` (
  `ID` int NOT NULL,
  `Nombre` varchar(30) NOT NULL,
  `Precio` float NOT NULL,
  `Descripcion` text NOT NULL,
  `FichaTecnica` text NOT NULL,
  `Publicado` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `Productos`
--

INSERT INTO `Productos` (`ID`, `Nombre`, `Precio`, `Descripcion`, `FichaTecnica`, `Publicado`) VALUES
(1, 'Rueda de Madera', 18, '<span>Práctica rueda de ejercicio ideal para que tu mascota se divierta y ejercite.</span><p>En esta rueda de ejercicio tu mascota podrá mantenerse en forma corriendo y estirando las patas, haciendo todo el ejercicio que necesita para estar sano. Los ratones y los degús tienen un instinto natural para ejercitarse, ya que en ocasiones suelen desplazarse muchos kilómetros en busca de comida. Cuando estos viven en el interior de una casa o en una jaula, sus posibilidades de recorrer largas distancias se reducen.</p><p> Al estar fabricado con madera, es un producto completamente natural e inocuo, por lo que no hay peligro si tu mascota los muerde. Puede instalarse dentro o fuera de la jaula. Tiene una base estable que evita que la rueda pueda caerse mientras el animal lo usa. Para hacer su uso más seguro tiene peldaños en el interior para que el animal pueda correr cómodamente.</p>', '<p> Detalles:<br>Proveedor: <a href=\"https://www.trixie.es/\">Trixie</a><br>Material: madera<br>Disponibilidad: Sí<br>Variedades: Sí</p><br><p>Variedades:<br>- Tipo madera: normal - lisa<br>- Tamaño(cm): pequeño - mediano - grande<br>Diámetro externo: 15 - 21 - 26<br>Diámetro interno: 14.4 - 19 - 28<br>Ancho base: 9 - 12 14<br>Altura: 17.5 - 23.5 - 32<br>Anchura externa de la rueda: 6 - 8 - 9.5<br>Anchura interna de la rueda: 5.3 - 7.2 - 8.6</p>', 1),
(2, 'Juego de tubos', 16.99, '<span>Set de tubos para roedores con varias piezas personalizable.</span><p> Divertido juego de tubos que incluye un total de 10 piezas: 1 tubo tres enlaces, 4 tubos curvos, 3 tubos rectos cortos y 2 tubos rectos largos. Se pueden desmontar y combinar libremente sin necesidad de pegamentos, clavos o tornillos. Son adecuados para hámsters, pequeños conejillos de indias, chinchillas, hurones y otros animales pequeños y pueden ser colocados en interiores y exteriores.</p><p> Están hechos de un material resistente y duradero, no se dañan fácilmente debido a las mordeduras ni a la actividad excesiva de tu mascota. Los tubos son transparentes para poder observar las actividades diarias de los animales pequeños en cualquier momento y registrar sus hábitos y están preparados para que el animal pueda respirar sin problema aunque pase mucho tiempo en ellos. Son resistente a las manchas, reutilizable y pueden ser lavados para mantenerlos limpios.</p>', '<p> Detalles: <br>Proveedor: LeapBeast <br>Material: polipropileno <br>Disponibilidad: Sí <br>Variedades: Sí <br>Tamaño de los tubos(cm): pequeño <br>- Diámetro: 7.8 <br>- Tres enlaces: 9.65 <br>- Curvos: 8 <br>- Rectos cortos: 8.9 <br>- Rectos largos: 15.70 </p><br><p> Variedades: <br>- Colores: transparente - rosa - celeste - verde </p>', 0),
(3, 'Hamaca cuadrada', 11.75, '<span>Cómoda hamaca para tus mascotas</span> <p> Esta suave y cómoda hamaca es perfecta para que tus mascotas descansen de forma segura descansando en la parte superior o acurrucándose en la parte inferior. Diversos modelos con distintos estampados y colores a elegir. </p> <p> Tejido liviano de doble capa de terciopelo suave que proporciona una cama cómoda y cálida para su mascota. Se fija fácil y rápidamente al interior de la jaula con los 4 ganchos de metal incluidos. Tiene una carga máxima de 3kg.</p>', '<p> Detalles: <br>Proveedor: Oncpcare <br>Material: terciopelo, metal <br>Disponibilidad: Sí <br>Variedades: Sí</p><br><p> Variedades: <br>- Colores: marrón - gris - azul - celeste - rosa - morado <br>- Diseño: liso - lunares - corazones - estrellas <br>- Tamaño(cm): pequeño (S) - mediano (M) <br>Ancho: 20 - 34 <br>Largo: 20 - 34 </p>', 1),
(4, 'Palitos de madera de kiwi', 5.5, '<span>Ricos palitos masticables de madera de kiwi</span> <p> Con estos palitos satisfacerá las necesidades naturales y el instinto de morder y roer Así tu mascota se mantendrá activa y entretenida durante muchas horas, evitando el aburrimiento y los comportamientos indeseados que éste provoca. Ideal para hámsters, cobayas, ardillas, etc. </p> <p> Los palitos de madera de kiwi, son totalmente digeribles por lo que estará ofreciendo a su mascota un complemento totalmente natural e inocuo. Es perfecto para mordisquearlo y gracias a su elevado contenido en fibras mantiene sus dientes cortos, saludables, ayuda a su desgaste natural y al correcto tránsito digestivo. Revisar regularmente el estado del juguete, cambiandolo cuando este deteriorado. </p>', '<p> Detalles: <br>Proveedor: Vadigran <br>Material: madera de kiwi <br>Disponibilidad: Sí <br>Variedades: No <br>Unidades: 10 unidades <br>Capacidad(ml): 150 - 300 - 600 <br>Dimensiones del envase(cm): <br>Longitud del palito(cm): 14.5 <br>Peso neto(gr): 40 </p>', 1),
(5, 'Bola de plástico', 5.99, '<span>Divertida bola de juego para pequeños roedores</span> <p> Esta bola permite que tus mascotas mezclar el juego y el ejercicio, genial para mantenerse en buena forma. Se abre girando la tapa hacia la izquierda, sin necesidad de tornillos u otras herramientas. Más resistente que otras bolas convencionales, es ligera y fácil de transportar. Ideal para hámsters, jerbos, ratones u otros animales pequeños. </p> <p> Hecho de plástico transparente para que tu mascota pueda ver claramente mientras está en su interior. Está diseñada con agujeros de aire que proporcionan horas de diversión activa sin problemas. Es resistente, seguro, no tóxico e insípido si tu mascota lo muerde. </p>', '<p> Detalles: <br>Proveedor: Swovo <br>Material: plástico <br>Disponibilidad: Sí <br>Variedades: Sí</p><br><p> Variedades: <br>- Colores: transparente - amarillo - celeste - rosado <br>- Tamaño(cm): pequeño - mediano - grande <br>Diámetro: 8 - 11 - 15 </p>', 1),
(6, 'Bebedero enganchable', 3.5, '<span>Útil bebedero para tus mascotas</span> <p> Estas botellas de bebida para los animales domésticos harán que tus mascotas puedan mantenerse hidratados y saciar su sed. Muy sencillas de instalar y fácil de usar, no requieren ninguna herramienta para poder rellenarlas. Disponibles en tres tamaños diferentes para todo tipo de mascotas y jaulas: pequeños hámsteres, hurones, cobayas, conejillos de Indias, etc. </p> <p> Hecho de plástico resistente y transparente para se pueda ver la cantidad de líquido que queda en su interior. Tiene una boquilla de acero inoxidable con válvula de esfera antigoteo que asegura una perfecta estanqueidad. Adaptable a todo tipo de jaulas de red de alambre gracias al práctico gancho con el que cuentan. </p>', '<p> Detalles: <br>Proveedor: Ferplast <br>Material: plástico, acero inoxidable <br>Disponibilidad: Sí <br>Variedades: Sí</p><br><p> Variedades: <br>- Colores: azul - rojo - blanco <br>- Capacidad(ml): 150 - 300 - 600 <br>- Tamaños(cm): <br>Diámetro: 8.5 - 10 - 11 <br>Alto: 17 - 18 - 24 <br>Boquilla: 4 - 5.5 - 6.5 </p>', 0),
(7, 'Jaula 100cm', 45.99, '<span>Una amplia y espaciosa jaula para tu mascota</span> <p> Esta jaula está bien equipado con los accesorios básicos imprescindibles para acoger a tu pequeño amigo. Contiene: un cuenco, un comedero de heno, un biberón y un refugio. Espaciosa, tu pequeña mascota se sentirá bien en ella pues necesita un espacio amplio para poder estirarse durante todo el día. </p> <p> La rejilla de la jaula está fijada con ganchos de plástico con la garantía de que tu mascota está bien protegida dentro de su espacio. La malla metálica es adecuada para su seguridad, está hecha de metal y es impermeable por lo que es muy duradera y, sobre todo, segura para tu mascota si intenta morder la malla. La parte delantera se puede abrir para facilitar el acceso a la jaula: práctica para limpiar o sacar a tu mascota. Además, para facilitarte el día a día, la limpieza de la bandeja es fácil porque es desmontable. Ideal para mantener un estilo de vida saludable para tu mascota en este espacio. </p>', '<p> Detalles: <br>Proveedor: Zoomalia <br>Material: Plástico, metal <br>Disponibilidad: Sí <br>Variedades: No</p> <br><p>Variedades: <br>- Dimensiones (cm): <br>Largo:100 <br>Ancho: 50 <br>Alto: 45 </p>', 1),
(8, 'Jaula dos pisos de vidrio', 62.55, '<span>Una amplia y espaciosa jaula de dos plantas para tu mascota</span> <p> Esta curiosa jaula híbrida tiene dos partes, la superior de metal, con barrotes, tiene una óptima ventilación y el espacio entre los barrotes es el adecuado para evitar incidentes o fugas. Y la parte o piso inferior, es de plástico transparente, para que puedas ver a tus pequeñas mascotas en todo momento.  La jaula Hábitat XL está equipada de una plataforma, una escalera, un biberón y de accesorios subterráneos. </p> <p> La rejilla de la parte de arriba de la jaula está fijada con ganchos garantizando de que tu mascota está bien protegida dentro de su espacio. La malla metálica es adecuada para su seguridad, está hecha de metal y es impermeable por lo que es muy duradera y, sobre todo, segura para tu mascota si intenta morder la malla y. La parte inferior es una sólida cubeta de vidrio, espaciosa y profunda, para permitir que tu mascota excave en el serrín y se esconda en él. La cubeta de vidrio permite ver siempre a tu pequeño amigo en su interior. La parte superior de alambre se puede separar completamente de la cubeta de vidrio. De esta manera, es posible acceder incluso a los puntos más sucios y difíciles de la jaula.</p>', '<p> Detalles: <br>Proveedor: Feplast <br>Material: Metal, vidrio <br>Disponibilidad: Sí <br>Variedades: No</p> <br><p>Variedades: <br>- Dimensiones (cm): <br>Largo:70 <br>Ancho: 37 <br>Alto: 56 <br>Distancia entre barrotes: 0.9 </p>', 1),
(9, 'Jaula de Madera rectangular', 65.75, '<span>Una amplia y divertida jaula para tu mascota</span> <p> Esta jaula para es la mejor opción si lo que estás buscando es un espacio con múltiples zonas de actividades para que tus mascotas se lo pasen genial y puedas satisfacer sus instintos naturales. Fabricada con madera de abeto macizo, cuenta con unas grandes ventanas de metacrilato para que puedas observarlos en todo momento, y la tapa con rejilla, es ideal para dotar la jaula de una óptima ventilación.</p> <p> Está hecha de madera de abeto maciza muy resistente y cuenta con dos amplias ventanas de metacrilato permiten una observación directa del exterior. Techo en forma de tapa que se puede abrir para facilitar su acceso y de rejilla metálica para proporcionar una buena ventilación. Esta jaula está compuesta por 4 plataformas, 2 escondites, 2 barras de salto, 2 columpios y una rampa. El diseño de esta jaula en varios niveles ofrece un gran espacio para que tus mascotas puedan descansar, jugar, escalar, etc. Cuenta con una bandeja extraíble en la parte inferior para facilitar su limpieza. Se requiere montaje.</p> ', '<p> Detalles: <br>Proveedor: Feplast <br>Material: madera, metal, metacrilato <br>Disponibilidad: Sí <br>Variedades: No</p> <br><p>Variedades: <br>- Dimensiones: Largo - Ancho - Alto (cm) <br>Totales: 78x40x44 <br>De la caseta de la rampa: 20 - 8.5 - 12.5 <br>De la caseta de orificios: 10 - 8.2 - 20 <br>De la rampa: 30 - 8 <br>De la plataforma 1: 34 - 11 <br>De la plataforma 2: 25 - 11 <br>De la plataforma 3: 18 - 11 <br>De la bandeja extraíble: 64 - 38 </p>', 0);

-- --------------------------------------------------------

--
-- Table structure for table `Usuarios`
--

CREATE TABLE `Usuarios` (
  `Correo` varchar(50) NOT NULL,
  `Passwrd` varchar(70) NOT NULL,
  `Nombre` varchar(40) NOT NULL,
  `ImagenPerfil` varchar(40) NOT NULL DEFAULT 'default.jpg',
  `Moderador` tinyint(1) NOT NULL DEFAULT '0',
  `GestorSitio` tinyint(1) NOT NULL DEFAULT '0',
  `GestorPermisos` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `Usuarios`
--

INSERT INTO `Usuarios` (`Correo`, `Passwrd`, `Nombre`, `ImagenPerfil`, `Moderador`, `GestorSitio`, `GestorPermisos`) VALUES
('admin@correo.es', '$2y$10$7wB/h5sYxo.YEJLQymm4nuAADwIYqaH5/Ph9fWwo177c9Idm6WN3q', 'Admin', 'perfil1.png', 1, 1, 1),
('gestor@correo.es', '$2y$10$9YYAEG./fhv2stzYm2EBPOrhmERfxt0sPh0S4Jk3GsfkWa7V/VdZi', 'Gestr', 'perfil1.png', 0, 1, 0),
('gestor2@correo.es', '$2y$10$9YYAEG./fhv2stzYm2EBPOrhmERfxt0sPh0S4Jk3GsfkWa7V/VdZi', 'Gestr', 'perfil2.png', 0, 0, 1),
('modd@correo.es', '$2y$10$PNHCJzZrNPj7o8Upm3WlNONoPLVJGIGvDXuV9Vx3DspsTGjcgMh4C', 'Moder', 'perfil3.png', 1, 0, 0),
('normal@correo.es', '$2y$10$aDkH0ZW9nTy.NWffR7r1R.x84POMdSy608BNj.dD5EpcRKzfIKpAy', 'Nrmal', 'perfil4.png', 0, 0, 0),
('user@gmail.com', '$2y$10$bg6gFgiZSFx.tT6mgomxlubJpy3ytAcD2PQ5GliQKlk5SsGNbX5Fq', 'Isa', 'perfil.jpeg', 0, 0, 0),
('user1@gmail.com', '$2y$10$hcMA.2CnZMh1lnRoc90QZOznS6gQ2ErPUuPoTVIYBxxEYTnA9yE1C', 'Pedro Santos', 'perfil1.jpeg', 0, 0, 0),
('user2@gmail.com', '$2y$10$fQNCSYdhbeazNZvmCQDZju1XVCuBCcUpNuuqN/0YHdQAoS99PJd7q', 'Celia', 'perfil2.jpeg', 0, 0, 0),
('user3@gmail.com', '$2y$10$xNNFZOpiuDK9WTW8p91bFeNeRm.f3bGHW5GYgp8WcCfzRGJ4xbHTO', 'Maite', 'perfil3.jpeg', 0, 0, 0),
('user4@gmail.com', '$2y$10$pOmabw0sJrqMU/6CzoFfD.bDgPNEVTlz83TOqqOs9bMJle7ogGdqm', 'Alberto', 'perfil4.jpg', 0, 0, 0),
('user5@gmail.com', '$2y$10$24XCPj9P3L2Im/vy55NkK.k7kAxRPoJUP8x7ULKrqKOUInBWoUCmS', 'Maria del Mar', 'perfil5.jpg', 0, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Comentarios`
--
ALTER TABLE `Comentarios`
  ADD PRIMARY KEY (`idComentario`),
  ADD UNIQUE KEY `idProducto_2` (`idProducto`,`idComentario`),
  ADD KEY `idProducto` (`idProducto`,`Fecha`);

--
-- Indexes for table `Etiquetas`
--
ALTER TABLE `Etiquetas`
  ADD UNIQUE KEY `idProducto_2` (`idProducto`,`Etiqueta`),
  ADD KEY `idProducto` (`idProducto`);

--
-- Indexes for table `Galeria`
--
ALTER TABLE `Galeria`
  ADD UNIQUE KEY `idProducto_2` (`idProducto`,`Imagen`,`Portada`),
  ADD KEY `idProducto` (`idProducto`);

--
-- Indexes for table `PalabrasBaneadas`
--
ALTER TABLE `PalabrasBaneadas`
  ADD UNIQUE KEY `Palabras` (`Palabras`);

--
-- Indexes for table `Productos`
--
ALTER TABLE `Productos`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `ID` (`ID`);

--
-- Indexes for table `Usuarios`
--
ALTER TABLE `Usuarios`
  ADD UNIQUE KEY `Correo_2` (`Correo`),
  ADD KEY `Correo` (`Correo`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Comentarios`
--
ALTER TABLE `Comentarios`
  MODIFY `idComentario` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `Productos`
--
ALTER TABLE `Productos`
  MODIFY `ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
