<?php
    require_once "/usr/local/lib/php/vendor/autoload.php";
    include("baseDatosProducto.php");

    $loader = new \Twig\Loader\FilesystemLoader('templates');
    $twig = new \Twig\Environment($loader);

    $numItem = 1;
    $producto = array();

    for ( $cont = 0; $cont < 9; $cont = $cont + 1 ) {
        $getProducto = getMostrarProducto($numItem + $cont);

        if($getProducto['ID'] != 0 ){ 
            $portada = getPortada($getProducto['ID']);
            $producto[] = array('ID'      => $getProducto['ID'],
                                'Nombre'  => $getProducto['Nombre'],
                                'Portada' => $portada);
        }
    };

    echo $twig->render('portada.html', ['Producto' => $producto] );
