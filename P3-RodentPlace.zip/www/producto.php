<?php
    require_once "/usr/local/lib/php/vendor/autoload.php";
    include("baseDatosProducto.php");
  
    $loader = new \Twig\Loader\FilesystemLoader('templates');
    
    $twig = new \Twig\Environment($loader);
    $twig->addExtension(new \Twig\Extension\StringLoaderExtension());


    if (isset($_GET['producto']) && filter_var($_GET['producto'], FILTER_VALIDATE_INT) ) {
        $idProducto = filter_var($_GET['producto'], FILTER_VALIDATE_INT);
    } else {
        $idProducto = -1;
    }

    $producto = getProducto($idProducto);
    $portada = getPortada($producto['ID']);
    if($producto['ID'] != 0 ){
        $imagenes = getGaleria($producto['ID'] );
        $seccionComentarios = getComentarios($producto['ID']);
    }

    echo $twig->render('producto.html', ['Producto' => $producto, 'Galeria' => $imagenes, 'Portada' => $portada, 'Comentarios' => $seccionComentarios]);
?>
