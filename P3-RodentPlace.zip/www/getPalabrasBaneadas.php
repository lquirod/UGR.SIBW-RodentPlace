<?php
    include("baseDatosProducto.php");

	$mysqli = conectarBD();
	if ($mysqli->connect_errno) {
		echo ("Fallo al conectar: " . $mysqli->connect_error);
	}

	$res = $mysqli->query("SELECT Palabras FROM PalabrasBaneadas");
	$palabras = array();

	while ($row = mysqli_fetch_assoc($res)) {
		$palabras[] = $row['Palabras'];
	}

	echo json_encode($palabras);
?>


