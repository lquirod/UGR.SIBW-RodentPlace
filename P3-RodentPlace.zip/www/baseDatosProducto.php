<?php
function conectarBD() {
	return new mysqli("mysql", "Rody", "rodentPlace", "SIBW");
}

function getProducto($idProducto) {
	$mysqli = conectarBD();
	if ($mysqli->connect_errno) {
		echo ("Fallo al conectar: " . $mysqli->connect_error);
	}

	$res = $mysqli->query("SELECT ID, Nombre, Precio, Descripcion, FichaTecnica
	FROM Productos WHERE ID=" . $idProducto);
	$producto = array('ID'          => '0',
	                  'Nombre'      => 'Producto no encontrado',
	                  'Precio'      => '-',
	                  'Descripcion' => '<p>Oops, parece que el producto que desea acceder no está. Compruebe que ha sido buscado correctamente o eche un vistazo a otros productos.</p>',
	                  'FichaTecnica'=> '<p>Errores: El producto deseado no ha sido identificado en nuestra base de datos.<br>Soluciones: Compruebe que la dirección haya sido escrita correctamente o busque otro producto.</p>',
	                   );

	if ($res->num_rows > 0) {
		$row = $res->fetch_assoc();
		$producto = array('ID'          => $row['ID'],
						  'Nombre'      => $row['Nombre'],
						  'Precio'      => $row['Precio'],
						  'Descripcion' => $row['Descripcion'],
						  'FichaTecnica'=> $row['FichaTecnica'],
						  );
	}

	return $producto;
}

function getMostrarProducto($idProducto) {
	$mysqli = conectarBD();
	if ($mysqli->connect_errno) {
		echo ("Fallo al conectar: " . $mysqli->connect_error);
	}

	$res = $mysqli->query("SELECT ID, Nombre FROM Productos WHERE ID=" . $idProducto);
	$nombreIdProducto = array('ID'     => '0',
							  'Nombre' => '-');

	if ($res->num_rows > 0) {
		$row = $res->fetch_assoc();
		$nombreIdProducto = array('ID'     => $row['ID'],
						  		  'Nombre' => $row['Nombre']);
	}

	return $nombreIdProducto;
}

function getPortada($idProducto) {
	$mysqli = conectarBD();
	if ($mysqli->connect_errno) {
		echo ("Fallo al conectar: " . $mysqli->connect_error);
	}

	$res = $mysqli->query("SELECT Imagen FROM Galeria WHERE idProducto=" . $idProducto . " AND Portada");
	
	if ($res->num_rows > 0) {
		$row = $res->fetch_assoc();
		$Portada = $row['Imagen'];
	}else{		
		$def = $mysqli->query("SELECT Imagen FROM Galeria WHERE idProducto='0' AND Portada");
		$row = $def->fetch_assoc();
		$Portada = $row['Imagen'];
	}

	return $Portada;
}

function getGaleria($idProducto) {
	$mysqli = conectarBD();
	if ($mysqli->connect_errno) {
		echo ("Fallo al conectar: " . $mysqli->connect_error);
	}

	$res = $mysqli->query("SELECT Imagen FROM Galeria WHERE idProducto=" . $idProducto . " AND ( Portada=0 OR Portada IS NULL) ");
	$Imagenes = array();

	while ($row = mysqli_fetch_assoc($res)) {
		$Imagenes[] = $row['Imagen'];
	}

	return $Imagenes;
}

function formatFecha($mysqlDate) {
	$formattedDate = date("H:i, d/m/Y", strtotime($mysqlDate));

	return $formattedDate;
}

function getComentarios($idProducto, $format = 1) {
	$mysqli = conectarBD();
	if ($mysqli->connect_errno) {
		echo ("Fallo al conectar: " . $mysqli->connect_error);
	}

	$res = $mysqli->query("SELECT Autor, Comentario, Fecha FROM Comentarios WHERE idProducto=" . $idProducto . " ORDER BY Fecha DESC ");
	$Comentarios = array();

	while ($row = mysqli_fetch_assoc($res)) {
		if($format){
			$Comentarios[] = array('Autor'     => $row['Autor'],
								   'Comentario'=> $row['Comentario'],
								   'Fecha'     => formatFecha($row['Fecha']));
		}else{
			$Comentarios[] = array('Autor'     => $row['Autor'],
								   'Comentario'=> $row['Comentario'],
								   'Fecha'     => $row['Fecha']);
		}
	}

	return $Comentarios;
}

?>


