<?php
  function conectUserBD() {
    return new mysqli("mysql", "Dodyy", "notAdmin", "SIBW");
  }
  function userAdmin() {
		return new mysqli("mysql", "Coddy", "yepAdmin", "SIBW");
	}
  // Devuelve true si existe un usuario con esa contraseña
  function checkLogin($correo, $pass) {    
    $mysqli = conectUserBD();
    if ($mysqli->connect_errno) {
      echo ("Fallo al conectar: " . $mysqli->connect_error);
    }
    $correo_secure = mysqli_real_escape_string($mysqli, $correo);

    $sql = "SELECT Passwrd FROM Usuarios WHERE Correo=\"".$correo_secure."\"";
    $res = $mysqli->query($sql);
		$user = 0;
		if ($res->num_rows > 0) {
      $row = $res->fetch_assoc();
			$Passwrd = $row['Passwrd'];
      if(password_verify($pass, $Passwrd )) {
        return true;
      }
		}

    return false;
  }
  
  // Devuelve la información de un usuario a partir de su nick 
  function getUser($correo) {
    $mysqli = conectUserBD();
    if ($mysqli->connect_errno) {
      echo ("Fallo al conectar: " . $mysqli->connect_error);
    }
    $correo_secure = mysqli_real_escape_string($mysqli, $correo);
    $sql = "SELECT Nombre, ImagenPerfil, Moderador, GestorSitio, GestorPermisos FROM Usuarios WHERE Correo=\"".$correo_secure."\"";
    $res = $mysqli->query($sql);
		if ($res->num_rows > 0) {
			$row = $res->fetch_assoc();
			$user = array('nombre'         => $row['Nombre'],
                    'correo'         => $correo_secure,
                    'imagenPerfil'   => $row['ImagenPerfil'],
                    'Moderador'      => $row['Moderador'],
                    'GestorSitio'    => $row['GestorSitio'],
                    'GestorPermisos' => $row['GestorPermisos']
              );
      return $user;
		}
    return 0;
  }

  function getAllUsers() {
    $mysqli = conectUserBD();
    if ($mysqli->connect_errno) {
      echo ("Fallo al conectar: " . $mysqli->connect_error);
    }
    $sql = "SELECT Correo, Nombre, ImagenPerfil, Moderador, GestorSitio, GestorPermisos FROM Usuarios";
    $res = $mysqli->query($sql);
    $user = array();
    if ($res->num_rows > 0)
		while ($row = mysqli_fetch_assoc($res)) {
			$user[] = array('nombre'      => $row['Nombre'],
                    'correo'         => $row['Correo'],
                    'imagenPerfil'   => $row['ImagenPerfil'],
                    'Moderador'      => $row['Moderador'],
                    'GestorSitio'    => $row['GestorSitio'],
                    'GestorPermisos' => $row['GestorPermisos']
              );
            }
    return $user;
  }

  function existeUser($correo) {
    $mysqli = conectUserBD();
    if ($mysqli->connect_errno) {
			echo ("Fallo al conectar: " . $mysqli->connect_error);
		}
    $correo_secure = mysqli_real_escape_string($mysqli, $correo);
    $sql = "SELECT Correo FROM Usuarios WHERE Correo=\"".$correo_secure."\"";
    $res = $mysqli->query($sql);
		if ($res->num_rows == 1) {
      return true;
		}
    return false;
  }


  function getBasicUser($correo) {
    $mysqli = conectUserBD();
    if ($mysqli->connect_errno) {
      echo ("Fallo al conectar: " . $mysqli->connect_error);
    }
    $correo_secure = mysqli_real_escape_string($mysqli, $correo);
    $sql = "SELECT Nombre, ImagenPerfil FROM Usuarios WHERE Correo=\"".$correo_secure."\"";
    $res = $mysqli->query($sql);
		if ($res->num_rows > 0) {
			$row = $res->fetch_assoc();
			$user = array('nombre'         => $row['Nombre'],
                    'imagenPerfil'   => $row['ImagenPerfil']
              );
      return $user;
		}
    return 0;
  }

  function addNormalUser($nombre, $correo, $password, $perfilImage) {
    $mysqli = conectUserBD();
    if ($mysqli->connect_errno) {
			echo ("Fallo al conectar: " . $mysqli->connect_error);
		}
    $correo_secure      = mysqli_real_escape_string($mysqli, $correo);
    $password_secure = password_hash($password, PASSWORD_DEFAULT);
    $nombre_secure      = mysqli_real_escape_string($mysqli, $nombre);
    $perfilImage_secure = mysqli_real_escape_string($mysqli, $perfilImage);

    $sql = "INSERT INTO Usuarios (Correo, Passwrd, Nombre, ImagenPerfil) VALUES ( '$correo_secure', '$password_secure', '$nombre_secure', '$perfilImage_secure')";
    $mysqli->query($sql);
    return $mysqli->affected_rows;
  }

  function editlUser($antiguoCorreo, $nombre, $correo, $password, $perfilImage) {
    $mysqli = conectUserBD();
    if ($mysqli->connect_errno) {
			echo ("Fallo al conectar: " . $mysqli->connect_error);
		}
    $AntiguoCorreo_secure      = mysqli_real_escape_string($mysqli, $antiguoCorreo);
    if($correo != ""){
      $correo_secure      = mysqli_real_escape_string($mysqli, $correo);
      $editCorreo = ", Correo = '$correo_secure' ";
    }
    $nombre_secure = mysqli_real_escape_string($mysqli, $nombre);
    if($perfilImage != ""){
      $perfilImage_secure = mysqli_real_escape_string($mysqli, $perfilImage);
      $editImage = ", ImagenPerfil = '$perfilImage_secure' ";
    }
    if($password != ""){
      $password_secure = password_hash($password, PASSWORD_DEFAULT);
      $editPass = ", Passwrd = '$password_secure' ";
    }

    $sql = "UPDATE Usuarios SET Nombre = '$nombre_secure' ".$editCorreo.$editImage.$editPass." WHERE Correo=\"".$AntiguoCorreo_secure."\"";
    $mysqli->query($sql);
    return $mysqli->affected_rows;
  }

  function editPermisosUser($correo, $mod, $sitio, $permisos) {
    $mysqli = conectUserBD();
    if ($mysqli->connect_errno) {
			echo ("Fallo al conectar: " . $mysqli->connect_error);
		}

    if($mod != 1)
      $mod = 0;
    
    if($sitio != 1)
      $sitio = 0;

    if($permisos != 1)
      $permisos = 0;

    if(existeUser($correo) && comprobarGestPermisos($correo, $permisos)){
      $correo_secure = mysqli_real_escape_string($mysqli, $correo);
      $sql = "UPDATE Usuarios SET Moderador = '$mod', GestorSitio = '$sitio', GestorPermisos = '$permisos' WHERE Correo=\"".$correo_secure."\"";
      $mysqli->query($sql);
      return $mysqli->affected_rows;
    }else{
      return 0;
    }
  }

  function comprobarGestPermisos($correo, $gest) {
    if(existeUser($correo) && $gest == 0){
      $mysqli = conectUserBD();
      if ($mysqli->connect_errno) {
        echo ("Fallo al conectar: " . $mysqli->connect_error);
      }
      $correo_secure = mysqli_real_escape_string($mysqli, $correo);
      
      $sql = "SELECT GestorPermisos FROM Usuarios WHERE GestorPermisos=1";
      $mysqli->query($sql);
      $numGest = $mysqli->affected_rows;

      $sql = "SELECT GestorPermisos FROM Usuarios WHERE GestorPermisos=1 AND Correo=\"".$correo_secure."\"";
      $mysqli->query($sql);
      $esGest = $mysqli->affected_rows;

      if($numGest == $esGest){
        return false;
      }

    }
    return true;
  }























?>
