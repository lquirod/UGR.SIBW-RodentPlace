<?php
  session_start();
  require_once "/usr/local/lib/php/vendor/autoload.php";
  require_once 'BD/bdUsuarios.php';

  $loader = new \Twig\Loader\FilesystemLoader('templates');
  $twig = new \Twig\Environment($loader);
  
  $varsParaTwig = [];
  
  if (isset($_SESSION['correo'])) {
    header("Location: miCuenta.php");
    exit();
  }
  
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $varsParaTwig['newName'] = $_REQUEST['newName'];
    $varsParaTwig['newEmail'] = $_REQUEST['newEmail'];
    $varsParaTwig['newPassword'] = $_REQUEST['newPassword'];
    $varsParaTwig['passwordRep'] = $_REQUEST['passwordRep'];
    $errors= array();

    if(isset($_FILES['imagen'])){
      $file_name = $_FILES['imagen']['name'];
      $file_size = $_FILES['imagen']['size'];
      $file_tmp = $_FILES['imagen']['tmp_name'];
      $file_type = $_FILES['imagen']['type'];
      $file_ext = strtolower(end(explode('.',$_FILES['imagen']['name'])));
      $extensions= array("jpeg","jpg","png");
      
      if($file_name!=""){
        if(in_array($file_ext,$extensions) === false){
          $errors[] = 'Extensión no permitida, elige una imagen JPEG o PNG.';
        }elseif ($file_size > 2097152){
          $errors[] = 'Tamaño del fichero demasiado grande';
        }else{
          $varsParaTwig['imagen'] = "images/perfil/" . $file_name;
        }
      }else{
        $file_name = "anonymous.jpg";
      }
    }

    // if($newPassword == $passwordRep){
    if(existeUser($varsParaTwig['newEmail'])){
      $errors[] = 'Este correo ya está registrado';
    }elseif(strcmp($varsParaTwig['newPassword'], $varsParaTwig['passwordRep'])){
      $errors[] = 'Las contraseñas no coinciden';       
    }
    
    if (empty($errors)==true) {
      $varsParaTwig['imagen'] = "images/perfil/". $file_name;
    
      $ret = addNormalUser($varsParaTwig['newName'],$varsParaTwig['newEmail'],$varsParaTwig['newPassword'], $file_name);
      if($ret){
        move_uploaded_file($file_tmp, "images/perfil/" . $file_name);
        $_SESSION['correo'] = $varsParaTwig['newEmail'];
        header("Location: miCuenta.php");
        exit();
      }else{
        $errors[] = 'No se ha podido realizar el registro, compruebe sus datos';
      }
    }
    if (sizeof($errors) > 0) {
      $varsParaTwig['errores'] = $errors;
    }
  }

  echo $twig->render('singup.html', $varsParaTwig);
?>