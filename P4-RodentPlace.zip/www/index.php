<?php
    session_start();
    require_once "/usr/local/lib/php/vendor/autoload.php";
    require_once 'BD/baseDatosProducto.php';
    require_once 'BD/bdUsuarios.php';

    $loader = new \Twig\Loader\FilesystemLoader('templates');
    $twig = new \Twig\Environment($loader);
    
    if (isset($_GET['page']) && (0 < filter_var($_GET['page'], FILTER_VALIDATE_INT))){
      $page = filter_var($_GET['page'], FILTER_VALIDATE_INT);
    }else{
      $page = 0;
    }

    $producto = array();
    $idProductos = getIDsProductos();
    $cont = 9*$page;
    if(!($cont < count($idProductos))){
      $cont = 0;
      $page = 0;
    }

    for (; $cont < 9+(9*$page) && $cont < count($idProductos); $cont = $cont + 1 ) {
        $getProducto = getMostrarProducto($idProductos[$cont]);
        if(existeIDProducto($getProducto['ID']) ){ 
            $portada = getPortada($getProducto['ID']);
            $producto[] = array('ID'      => $getProducto['ID'],
                                'Nombre'  => $getProducto['Nombre'],
                                'Portada' => $portada);
        }
    };
    if($cont+1 < count($idProductos)){
      $SigPage = true;
    }else{
      $SigPage = false;
    }
      if (isset($_SESSION['correo'])) {
        $user = getUser($_SESSION['correo']);
      }
      
    echo $twig->render('portada.html', ['Producto' => $producto, 'user' => $user, 'Page' => $page, 'SigPage' => $SigPage] );
?>

