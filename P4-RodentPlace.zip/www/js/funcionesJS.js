// Archivo JavaScript con lass funciones que que se realizan en
// la página web
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
// Función que pliega y despliega la sección de comentarios en las página producto
function toggleSeccion(seccion) {
    var section = document.getElementById(seccion);
    if (section.classList.contains('hidden')) {
        section.classList.remove('hidden');
        setTimeout(function () {
        section.classList.remove('visuallyHidden');
        }, 5);

    } else {
        section.classList.add('visuallyHidden');    
        section.addEventListener('transitionend', function(e) {
        section.classList.add('hidden');
        }, {
        capture: false,
        once: true,
        passive: false
        });
    }
}
//* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
// Funciones que gestionan el formulario de la sección de comentarios en la página de productos
//Notificación al usuario si algo falla en el formulario
function notificar(faltanCampos){
    alert('Para poder enviar su comentario necesita:'+ faltanCampos + ' por favor.' );
}
//* * * * * * * * * * * * * * * * * * * */
function filtrar(columnas) {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("Buscador");
    filter = input.value.toUpperCase();
    table = document.getElementById("tabla");
    tr = table.getElementsByTagName("tr");
    for (i = 1; i < tr.length; i++) {
        encontrado = false;
        for (var j = 0; j < columnas.length && !encontrado; j++){
            td = tr[i].getElementsByTagName("td")[columnas[j]];
            if (td) {
                txtValue = td.textContent || td.innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    encontrado = true;
                    tr[i].style.display = "";
                }
            }else{
                encontrado = true;
            }
        }
        if(encontrado){
            tr[i].style.display = "";
        }else{
            tr[i].style.display = "none";
        }
    }
}




