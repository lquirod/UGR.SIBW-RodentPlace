<?php
    session_start();
    require_once "/usr/local/lib/php/vendor/autoload.php";
    require_once "BD/baseDatosProducto.php";
    require_once 'BD/bdUsuarios.php';
  
    $loader = new \Twig\Loader\FilesystemLoader('templates');
    
    $twig = new \Twig\Environment($loader);
    $twig->addExtension(new \Twig\Extension\StringLoaderExtension());

    if (isset($_SESSION['correo'])) {
        $user = getUser($_SESSION['correo']);
    }else{
        header("Location: login.php");
        exit();
    }
    if($user['GestorSitio']){
        if ($_SERVER['REQUEST_METHOD'] === 'POST' ) {
            $newName = $_REQUEST['newName'];
            $newPrecio = $_REQUEST['newPrecio'];
            $newDescripcion = $_REQUEST['newDescripcion'];
            $newFichaTecnica = $_REQUEST['newFichaTecnica'];
            $errors = array();

            if (is_float($newPrecio) || 0 >= $newPrecio ){
                $errors[] = 'No es un precio válido';   
            }
            if (empty($errors)==true) {
                $ret = addProducto($newName,$newPrecio,$newDescripcion, $newFichaTecnica);
                if($ret){
                    header("Location: gestProducto.php?producto=".$newID);
                    exit();
                }else{
                    $errors[] = 'No se ha podido añadir el producto, compruebe los datos';
                }
            }
            if (sizeof($errors) > 0) {
                $errores = $errors;
            }
        }
    }else{
        header("Location: index.php");
        exit();
    }

    echo $twig->render('addProducto.html', ['user' => $user, 'newName' => $newName, 'newPrecio' => $newPrecio, 'newDescripcion' => $newDescripcion, 'newFichaTecnica' => $newFichaTecnica, 'errores' => $errors] );
?>
