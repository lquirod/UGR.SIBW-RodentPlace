<?php
    session_start();
    require_once "/usr/local/lib/php/vendor/autoload.php";
    require_once "BD/baseDatosProducto.php";
    require_once 'BD/bdUsuarios.php';
  
    $loader = new \Twig\Loader\FilesystemLoader('templates');
    
    $twig = new \Twig\Environment($loader);
    $twig->addExtension(new \Twig\Extension\StringLoaderExtension());

    // Si está iniciado sesión se toma la información del usuario
    // Si no, se redirige al login
    if (isset($_SESSION['correo'])) {
        $user = getUser($_SESSION['correo']);
    }else{
        header("Location: login.php");
        exit();
    }

    // Si no tiene permisos se redirige a la página principal
    if($user['GestorSitio']){
        if (isset($_GET['producto']) && filter_var($_GET['producto'], FILTER_VALIDATE_INT)
        && existeIDProducto(filter_var($_GET['producto'], FILTER_VALIDATE_INT) ) ){
            $idProducto = filter_var($_GET['producto'], FILTER_VALIDATE_INT);
            if($idProducto){
                $editProducto = getProducto($idProducto);
                $editProducto['Portada'] = getPortada($idProducto);
                $editProducto['Galeria'] = getGaleria($idProducto);
                $editProducto['Etiquetas'] = getEtiquetas($idProducto);
            }
        }
        $todosProductos = getProducto("TODO");
        $todasEtiquetas = getEtiquetas();
        foreach($todosProductos as &$unProducto) {
            $unProducto['Portada'] = getPortada($unProducto['ID']);
            $unProducto['Galeria'] = getGaleria($unProducto['ID']);
            $unProducto['Etiquetas'] = getEtiquetas($unProducto['ID']);
        }
    }else{
        header("Location: index.php");
        exit();
    }

    echo $twig->render('editProducto.html', ['todosProductos' => $todosProductos, 'todasEtiquetas' => $todasEtiquetas, 'user' => $user, 'editProducto' => $editProducto]);
?>