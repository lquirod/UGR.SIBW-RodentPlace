<?php
  session_start();
  require_once "/usr/local/lib/php/vendor/autoload.php";
  require_once 'BD/bdUsuarios.php';

  $loader = new \Twig\Loader\FilesystemLoader('templates');
  $twig = new \Twig\Environment($loader);
  
  $varsParaTwig = [];
  $errors = [];
      
  if (!isset($_SESSION['correo'])) {
    header("Location: login.php");
    exit();
  }
  $user = getUser($_SESSION['correo']);

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $correo = $_SESSION['correo'];
    $Email = $_REQUEST['Email'];
    $newEmail = $_REQUEST['newEmail'];
    $newName = $_REQUEST['newName'];
    $newPassword = $_REQUEST['newPassword'];
    $passwordRep = $_REQUEST['passwordRep'];
    $antiguaPasswrd = $_REQUEST['Password'];

    if(isset($_FILES['imagen'])){
      $file_name = $_FILES['imagen']['name'];
      $file_size = $_FILES['imagen']['size'];
      $file_tmp = $_FILES['imagen']['tmp_name'];
      $file_type = $_FILES['imagen']['type'];
      $file_ext = strtolower(end(explode('.',$_FILES['imagen']['name'])));
      $extensions= array("jpeg","jpg","png");
      
      if($file_name!=""){
        if(in_array($file_ext,$extensions) === false){
          $errors[] = 'Extensión no permitida, elige una imagen JPEG o PNG.';
        }elseif ($file_size > 2097152){
          $errors[] = 'Tamaño del fichero demasiado grande';
        }else{
          $imagen = "images/perfil/" . $file_name;
        }
      }
    }

    if( $newEmail!="" && existeUser($newEmail)){
      $errors[] = 'Este correo ya está en uso por un usuario existente';
    }
    if(strcmp($newPassword, $passwordRep)){
      $errors[] = 'La nueva contraseña no coincide';
    }
    if(!checkLogin($correo, $antiguaPasswrd )){
      $errors [] = 'La antigua contraseña no es correcta';
    }

    if (empty($errors)==true && !strcmp($user['correo'], $Email)) {
      $ret = editlUser($correo, $newName,$newEmail,$newPassword, $file_name);
      if($ret){
        move_uploaded_file($file_tmp, "images/perfil/" . $file_name);
      }else{
        $errors[] = 'No se ha podido modificar su perfil, compruebe sus datos';
      }
    }
  }

  $user = getUser($_SESSION['correo']);

  echo $twig->render('miCuenta.html', ['user' => $user, 'errores' => $errors]);
?>